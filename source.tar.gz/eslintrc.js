/* eslint linebreak-style: ["error", "windows"] */

module.exports = {
  env: {
    browser: true,
    es2021: true,
  },
  extends: ['plugin:react/recommended', 'airbnb'],
  parserOptions: {
    ecmaFeatures: {
      jsx: true,
    },
    ecmaVersion: 'latest',
    sourceType: 'module',
  },
  plugins: ['react'],
  rules: {
    'react/react-in-jsx-scope': 0,
    'react/jsx-filename-extension': 0,
    'no-underscore-dangle': 0,
    'react/no-unescaped-entities': 0,
    'import/prefer-default-export': 0,
    'no-param-reassign': 0,
    'react/jsx-props-no-spreading': 0,
    'max-len': 0,
    'no-unused-vars': 'off',
    'jsx-quotes': 'off',
    'linebreak-style': 0,
    'no-trailing-spaces': 0,
    'no-multiple-empty-lines': 0,
    'react/jsx-tag-spacing': 0,
    'array-bracket-spacing': 0,
    'import/order': 0,
    'no-restricted-syntax': 0,
    'jsx-a11y/click-events-have-key-events': 0,
    'react/no-array-index-key': 0,
  },
};
