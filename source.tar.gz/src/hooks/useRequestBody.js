import { useCallback } from "react";
import { useSelector } from "react-redux";
import moment from "moment";

const useRequestBody = () => {
  const quoteRequest = useSelector((state) => state?.quoteRequest ?? {});
  const apiResult = useSelector((state) => state?.apiResult ?? {});
  const user = useSelector((state) => state?.user);
  const {
    mailingAddressComponent: mailing,
    propertyAddressComponent: property,
  } = apiResult;

  let applicantInfo = {
    email: quoteRequest.emails[0],
    firstName: quoteRequest.firstName,
    lastName: quoteRequest.lastName,
    dob: moment(quoteRequest.dob).format("YYYY-MM-DD"),
    birthday: moment(quoteRequest.dob).format("YYYY-MM-DD"),
  };
  let mailingAddressComponentToSent = {
    address: mailing.street_number.long_name + " " + mailing.route.long_name,
    street: mailing.street_number.long_name + " " + mailing.route.long_name,
    state: mailing.administrative_area_level_1.short_name,
    city: mailing.locality.long_name,
    postalCode: mailing.postal_code.long_name,
  };
  let propertyAddressComponentToSent = {
    address: property.street_number.long_name + " " + property.route.long_name,
    street: property.street_number.long_name + " " + property.route.long_name,
    state: property.administrative_area_level_1.short_name,
    city: property.locality.long_name,
    postalCode: property.postal_code.long_name,
  };

  const nationwideHomeBody = useCallback(
    (optionals) => {
      const securityFireOrSmokeAlarmOption = {
        Monitored: "CentralFireAlarm_Ext",
        Cameras: "LocalAlarm",
        None: "LocalAlarm",
      };

      const securityBurglarAlarmOption = {
        Monitored: "CentralBurglarAlarm_Ext",
        Cameras: "LocalAlarm_Ext",
        None: "LocalAlarm_Ext",
      };

      const constructionTypeOption = {
        Frame: "Frame_Ext",
        Masonry: "BrickStoneMasonry",
        Concrete: "BrickStoneMasonry",
        Steel: "FireResistive",
        Log: "Log_Ext",
        Other: "Frame_Ext",
      };

      const sidingTypeOption = {
        Vinyl: "SidingVinyl",
        Aluminum: "SidingAluminum",
        Stucco: "StuccoOnFrame",
        Brick: "BrickOnFrame",
        Stone: "StoneOnFrame",
        Wood: "WoodShingle_Ext",
        Other: "SidingVinyl",
      };

      const roofTypeOption = {
        "Asphalt shingle": "CompositionShingle_Ext",
        "Wood shingle": "WoodShingle_Ext",
        "Slate roof": "Slate_Ext",
        Rubber: "Rubber_Ext",
        "Concrete Tile": "TileClay",
        Solar: "CompositionShingle_Ext",
        "Tile roof": "TileClay",
        "Tar and Gravel": "TarGravel",
        "Composition Shingle": "CompositionShingle_Ext",
      };

      let body = {
        ...applicantInfo,
        ...propertyAddressComponentToSent,
        phone: quoteRequest?.phone,
        agencyCode: user?.nationwide_api?.code,
        producerCode: user?.nationwide_api?.producerCode,
        policyStartDate: moment(quoteRequest.policyStartDate).format(
          "YYYY-MM-DD"
        ),
        square: quoteRequest.squareFeet,
        yearBuilt: quoteRequest.yearBuilt,
        numberOfFullBathrooms: quoteRequest.numberOfFullBathrooms,
        numberOfHalfBathrooms: quoteRequest.numberOfHalfBathrooms,
        numberOfStories: quoteRequest.numberOfStories,
        foundation: quoteRequest.foundation,
        constructionType: quoteRequest.constructionType,
        securitySystem: quoteRequest.securitySystem,
        sidingType: quoteRequest.sidingType,
        roofType: quoteRequest.roofType,
        dwellingCoverage:
          apiResult?.dwellingCoverageHippo ||
          apiResult?.dwellingCoverageRealtor ||
          quoteRequest.squareFeet * 170 ||
          0,
        ...optionals,
      };

      body.constructionType =
        constructionTypeOption?.[body.constructionType] || "Frame_Ext";
      body.fireOrSmokeAlarm =
        securityFireOrSmokeAlarmOption?.[body.securitySystem] ||
        "LocalAlarm_Ext";
      body.burglarAlarm =
        securityBurglarAlarmOption?.[body.securitySystem] || "LocalAlarm_Ext";
      body.sidingType = sidingTypeOption?.[body.sidingType] || "SidingVinyl";
      body.roofType =
        roofTypeOption?.[body.roofType] || "CompositionShingle_Ext";

      return body;
    },
    [quoteRequest, apiResult]
  );

  const travelerHomeBody = useCallback(
    (optionals) => {
      const foundationOption = {
        // Basement: "CN",
        Slab: "Slab",
        // Other: "N",
      };

      const securityOption = {
        Monitored: "CN",
        Cameras: "LO",
        None: "N",
      };

      const constructionTypeOption = {
        Frame: "F",
        Masonry: "MY",
        Concrete: "Pconcrete",
        Steel: "Steel",
        Log: "L",
        Other: "F",
      };

      const sidingTypeOption = {
        Vinyl: "I",
        Aluminum: "A",
        Stucco: "S",
        Brick: "BrkVen",
        Stone: "StoneVen",
        Wood: "WoodSid",
        Other: "I",
      };

      const roofShapeOption = {
        Peaked: "GABLE",
        Flat: "FLAT",
      };

      const roofTypeOption = {
        "Asphalt shingle": "ASPHS",
        "Wood shingle": "WOODSS",
        "Slate roof": "SLAT",
        Rubber: "RUBB",
        "Concrete Tile": "CLAY",
        "Tile roof": "CLAY",
        "Tar and Gravel": "TARGRB",
        "Composition Shingle": "ASPHS",
      };

      const roofYearOption = {
        "1-5 yr": new Date().getFullYear() - 4,
        "5-20 yr": new Date().getFullYear() - 19,
        "20+ yr": new Date().getFullYear() - 20,
      };

      const heatSourceOption = {
        "Central Gas": "com.travelers_GasCentral",
        "Central Electric": "com.travelers_ElectricCentral",
        "Central Oil": "com.travelers_OilCentral",
        Other: "com.travelers_Other",
        None: "com.travelers_Other",
        "I don't know": "com.travelers_Other",
      };

      let body = {
        ...applicantInfo,
        ...propertyAddressComponentToSent,
        agencyCode: user?.traveler_api?.code,
        phone: quoteRequest?.phone,
        policyStartDate: moment(quoteRequest.policyStartDate).format(
          "YYYY-MM-DD"
        ),
        square: quoteRequest.squareFeet,
        yearBuilt: quoteRequest.yearBuilt,
        numberOfFullBathrooms: quoteRequest.numberOfFullBathrooms,
        numberOfHalfBathrooms: quoteRequest.numberOfHalfBathrooms,
        numberOfStories: quoteRequest.numberOfStories,
        foundation: quoteRequest.foundation,
        constructionType: quoteRequest.constructionType,
        securitySystem: quoteRequest.securitySystem,
        sidingType: quoteRequest.sidingType,
        roofAge: quoteRequest.roofAge,
        roofType: quoteRequest.roofType,
        roofShape: quoteRequest.roofShape,
        heatSource: quoteRequest.heatSource,
        dwellingCoverage:
          apiResult?.dwellingCoverageHippo ||
          apiResult?.dwellingCoverageRealtor ||
          quoteRequest.squareFeet * 170 ||
          0,
        ...optionals,
      };

      body.phone =
        "+1-" +
        body.phone?.substring(0, 3) +
        "-" +
        body.phone?.substring(body.phone?.length - 7);

      // body.foundation = foundationOption?.[body.foundation] || "Slab";
      body.constructionType =
        constructionTypeOption?.[body.constructionType] || "F";
      body.securitySystem = securityOption?.[body.securitySystem] || "N";
      body.sidingType = sidingTypeOption?.[body.sidingType] || "I";
      if (
        ["MY", "Pconcrete"].includes(body.constructionType) &&
        ["BrkVen", "StoneVen"].includes(body.sidingType)
      ) {
        body.sidingType = "StoneSolCus";
      }
      body.roofAge = roofYearOption?.[body.roofAge] || 2020;
      body.roofType = roofTypeOption?.[body.roofType] || "ASPHS";
      body.roofShape = roofShapeOption?.[body.roofShape] || "FLAT";
      body.heatSource =
        heatSourceOption?.[body.heatSource] || "com.travelers_Other";

      return body;
    },
    [quoteRequest, apiResult, user]
  );

  const aaaHomeBody = useCallback(
    (optionals) => {
      let body = {
        ...applicantInfo,
        ...propertyAddressComponentToSent,
        countryCode: mailing.country.short_name,
        agencyCode: user?.aaa_api?.code,
        square: quoteRequest.squareFeet.toString(),
        yearBuilt: quoteRequest.yearBuilt.toString(),
        ...optionals,
      };
      return body;
    },
    [quoteRequest, apiResult]
  );

  const nationwideAutoBody = useCallback(
    (optionals) => {
      let body = {
        ...applicantInfo,
        ...mailingAddressComponentToSent,
        agencyCode: user?.nationwide_api?.code,
        producerCode: user?.nationwide_api?.producerCode,
        cars: quoteRequest.householdCars,
        ...optionals,
      };
      return body;
    },
    [quoteRequest]
  );

  const travelerAutoBody = useCallback(
    (optionals) => {
      let body = {
        ...applicantInfo,
        ...mailingAddressComponentToSent,
        agencyCode: user?.traveler_api?.code,
        phone: quoteRequest?.phone,
        drivers: quoteRequest.householdMembers,
        cars: quoteRequest.householdCars,
        ...optionals,
      };
      
      body.drivers = body?.drivers
        ?.filter(
          (item) =>
            new Date().getFullYear() - new Date(item?.birthday)?.getFullYear() >
            16
        )
        ?.map((item) => ({
          ...item,
          gender: item?.gender === "Female" ? "F" : "M",
          birthday: moment(item.birthday).format("YYYY-MM-DD"),
        }));

      body.phone =
        "+1-" +
        body.phone?.substring(0, 3) +
        "-" +
        body.phone?.substring(body.phone?.length - 7);

      return body;
    },
    [quoteRequest]
  );

  const aaaAutoBody = useCallback(
    (optionals) => {
      let body = {
        ...applicantInfo,
        ...mailingAddressComponentToSent,
        agencyCode: user?.aaa_api?.code,
        cars: quoteRequest.householdCars,
        ...optionals,
      };
      return body;
    },
    [quoteRequest]
  );

  return {
    nationwideHomeBody,
    nationwideAutoBody,
    travelerHomeBody,
    travelerAutoBody,
    aaaHomeBody,
    aaaAutoBody,
  };
};

export default useRequestBody;
