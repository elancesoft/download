export const convertToSortSize = (num, fixed = 2) => {
  let units = ["b", "K", "M", "B", "T", "Q"];
  let count = 0;
  while (num >= 1000) {
    num /= 1000;
    count++;
  }
  for (let i = 0; i < fixed; i++) {
    if (num === +num.toFixed(i)) return num.toFixed(i) + units[count];
  }
  return num.toFixed(2) + units[count];
};

export const getGeocode = (address) =>
  new Promise((resolve, reject) => {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      {
        address: address,
      },
      (results) => {
        if (results.length === 0) {
          reject();
        }

        let addressComponent = {};

        for (let component of results?.[0]?.address_components) {
          addressComponent[component.types[0]] = component;
        }

        console.log(address, addressComponent);

        resolve({
          addressComponent,
          geometry: results?.[0]?.geometry,
        });
      }
    );
  });

export const getAddressComponent = (address) =>
  new Promise((resolve, reject) => {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      {
        address: address,
      },
      (results) => {
        if (results?.length === 0 || !results) {
          return reject();
        }

        let addressComponent = {};

        for (let component of results?.[0]?.address_components) {
          addressComponent[component.types[0]] = component;
        }

        console.log(address, addressComponent);

        resolve(addressComponent);
      }
    );
  });
