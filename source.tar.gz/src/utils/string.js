import getConfig from "next/config";

const {
  publicRuntimeConfig: { BASE_IMAGE_URL },
} = getConfig();

export const convertToSortSize = (num, fixed = 2) => {
  let units = ["B", "K", "M", "B", "T", "Q"];
  let count = 0;
  while (num >= 1000) {
    num /= 1000;
    count++;
  }
  for (let i = 0; i < fixed; i++) {
    if (num === +num.toFixed(i)) return num.toFixed(i) + units[count];
  }
  return num.toFixed(2) + units[count];
};

export const getImage = (image) => {
  if (!image) {
    return "";
  }
  return `${BASE_IMAGE_URL}/${image}`;
};
