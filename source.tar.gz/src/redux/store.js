import { configureStore, combineReducers } from '@reduxjs/toolkit';
import { createWrapper, HYDRATE } from 'next-redux-wrapper';

import userReducer from './slices/userSlice';
import quoteRequestReducer from './slices/quoteRequestSlice';
import branchReducer from './slices/branchSlice';
import apiResultReducer from './slices/apiResultSlice';

const combinedReducer = combineReducers({
  user: userReducer,
  quoteRequest: quoteRequestReducer,
  branch: branchReducer,
  apiResult: apiResultReducer,
});

const reducer = (state, action) => {
  switch (action.type) {
    case HYDRATE:
      return {
        ...state,
        ...action.payload,
      };
    default:
      return combinedReducer(state, action);
  }
};

const createStore = () => configureStore({ reducer });

const store = createWrapper(createStore);
export default store;
