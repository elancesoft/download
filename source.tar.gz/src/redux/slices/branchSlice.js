import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  drivers: [],
  cars: [],
  selectedCars: [],
};

export const { reducer, actions } = createSlice({
  name: "branch",
  initialState,
  reducers: {
    updateBranchByApiResponse: (state, action) => {
      state.drivers =
        action.payload?.requestQuote?.quote?.drivers?.map((item) => ({
          ...item,
          isToggleOn: false,
        })) || [];
      state.cars =
        action.payload?.requestQuote?.quote?.cars?.map((item) => ({
          ...item,
          isToggleOn: false,
          type: item.make || "",
        })) || [];
    },
    toggleOnDriver: (state, action) => {
      state.drivers = state.drivers.map((item) => {
        if (item.id === action.payload?.id) {
          item.isToggleOn = true;
        }
        return item;
      });
    },
    toggleOffDriver: (state, action) => {
      state.drivers = state.drivers.map((item) => {
        if (item.id === action.payload?.id) {
          item.isToggleOn = false;
        }
        return item;
      });
    },
    toggleOnCar: (state, action) => {
      state.cars = state.cars.map((item) => {
        console.log(item.VIN, action.payload?.VIN)
        if (item.VIN === action.payload?.VIN) {
          item.isToggleOn = true;
        }
        return item;
      });
    },
    toggleOffCar: (state, action) => {
      state.cars = state.cars.map((item) => {
        if (item.VIN === action.payload?.VIN) {
          item.isToggleOn = false;
        }
        return item;
      });
    },
    addSelectCar: (state, action) => {
      state.selectedCars = [...state.selectedCars, { ...action.payload }];
    },
    removeSelectCar: (state, action) => {
      state.selectedCars = state.selectedCars.filter(
        (item) => item.VIN !== action.payload.VIN
      );
    },
  },
});

// Reducers and actions
export const {
  updateBranchByApiResponse,
  addSelectCar,
  removeSelectCar,
  toggleOnDriver,
  toggleOffDriver,
  toggleOnCar,
  toggleOffCar,
} = actions;
export default reducer;
