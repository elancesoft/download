import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  riskPage: false,
  firstname: '',
  lastname: '',
  email: '',
  phone: '',
  agentimage: '',
  link: '',
  linkImage: '',
  agencyname: '',
  role: '',
  additional_email: '',
  api_status: '',
  spreadsheet_id: '',
  emailtext: '',
  full_app_sheet_id: '',
  plymouth_api: '',
  universal_api: '',
  stillwater_api: '',
  neptuneflood_api: '',
  havenlife_api: '',
  ethoslife_api: '',
  hippo_api: '',
  created_at: '',
  propertyimage: '',
  introimage: '',
  agencyimage: '',
  autoimage: '',
  householdimage: '',
};

export const { reducer, actions } = createSlice({
  name: 'user',
  initialState,
  reducers: {
    updateUser: (state, action) => action.payload,
  },
});

// Reducers and actions
export const { setUser, resetUser, updateUser } = actions;
export default reducer;
