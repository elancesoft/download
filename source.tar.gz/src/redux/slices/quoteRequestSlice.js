import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

export const { reducer, actions } = createSlice({
  name: "quoteRequest",
  initialState,
  reducers: {
    updateQuote: (state, action) => {
      return { ...state, ...action.payload };
    },
    updateQuoteByField: (state, action) => {
      if (state[action.payload.field]) {
        state[action.payload.field] = {
          ...state[action.payload.field],
          ...action.payload.value,
        };
      } else {
        state[action.payload.field] = action.payload.value;
      }
    },
  },
});

// Reducers and actions
export const { updateQuote } = actions;
export default reducer;
