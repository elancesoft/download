import { createSlice } from "@reduxjs/toolkit";

const initialState = {};

export const { reducer, actions } = createSlice({
  name: "apiResult",
  initialState,
  reducers: {
    updateApiResult: (state, action) => {
      // for (let api in action.payload) {
      //   console.log(api);
      //   state[api] = {
      //     value: action.payload?.[api],
      //     count: (state?.[api]?.count || 0) + 1,
      //   };
      // }
      return ({ ...state, ...action.payload });
    },
  },
});

// Reducers and actions
export const { updateApiResult } = actions;
export default reducer;
