import axios from "axios";
import getConfig from "next/config";

const {
  publicRuntimeConfig: { API_URL },
} = getConfig();

export const createApiClient = async (customConfigs = {}) => {
  if (typeof global.axiosApiClient === "undefined") {
    const axiosConfigs = {
      baseURL: API_URL ?? "",
      timeout: 50000, 
      ...customConfigs,
    };

    global.axiosApiClient = axios.create(axiosConfigs);
  }
  return global.axiosApiClient;
};
