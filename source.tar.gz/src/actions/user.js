import humps from 'humps';
import { createApiClient } from '../configs/api-client';

export const userRetrieve = async () => {
  try {
    const apiClient = await createApiClient();
    const response = await apiClient.get('/user', {});

    const responseData = response?.data ?? {};
    return humps.camelizeKeys(responseData);
  } catch (error) {
    console.error(error);
    return null;
  }
};

export const getAllUser = async (options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.get('/api/all', {});
};

export const getUserByLink = async (link, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.get('/api/get_user_by_link/' + link, {});
};

export const submitFormApply = async (formData ,options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/submit_form_apply', formData, options);
};

export const updateFormApply = async (body ,options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/update_form_apply', body, options);
};
