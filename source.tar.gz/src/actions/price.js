import { createApiClient } from '../configs/api-client';

export const getBranch = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/branch', body, options);
};

export const getZillow = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_zillow', body, options);
};

export const getNationwide = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_nationwide_home', body, options);
};

export const getNationwideAuto = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_nationwide_auto', body, options);
};

export const getFlood = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_flood', body, options);
};

export const getEthosLife = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_ethoslife', body, options);
};

export const getHippo = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_hippo', body, options);
};

export const getAAAHome = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_aaa_home', body, options);
};

export const getAAAAuto = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_aaa_auto', body, options);
};

export const getTravelerHome = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_traveler_home', body, options);
};

export const getTravelerAuto = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/get_traveler_auto', body, options);
};
