import { createApiClient } from '../configs/api-client';

export const sendMailUploadFile = async (formData, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/send_adavace_life_upload_doc_email', formData, options);
};

export const sendMailAccurateQuote = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/send_accurate_quote_mail', body, options);
};

export const sendMailLineOfBusiness = async (body, options = {}) => {
  const apiClient = await createApiClient();
  return apiClient.post('/api/send_line_of_business_mail', body, options);
};

