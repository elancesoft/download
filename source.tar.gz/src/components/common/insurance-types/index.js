import { useState, Fragment } from 'react';
import {
  Checkbox, Col, Image, Row,
} from 'antd';
import {
  string, arrayOf, shape, func,
} from 'prop-types';

import iconDiscount from '../../../../public/images/pages/application/application_form_icon_discount.svg';

function Module({ current, insuranceTypes, onSelected }) {
  const [choice, setChoice] = useState(current);

  const handleCheckboxClicked = (e, value) => {
    const isSelected = e?.target?.checked ?? null;
    if (isSelected) setChoice(value);
    onSelected(value);
  };

  return (
    <Row
      className="list-insurances"
      gutter={[ 24, 24 ]}
    >
      {
        insuranceTypes.map((insuranceType, i) => (
          <Fragment key={i}>
            <Col
              className={insuranceType.value === 'Bundle' ? 'bundle-type' : ''}
              key={insuranceType.label}
              span={24}
            >
              {
                insuranceType.value === 'Bundle' && (
                  <Image rootClassName="icon-discount" preview={false} src={iconDiscount.src} alt="" />
                )
              }
              <Checkbox
                checked={choice === insuranceType.value}
                onChange={(e) => handleCheckboxClicked(e, insuranceType.value)}
              >
                <div className={`content${(choice === insuranceType.value) ? ' active' : ''}`}>
                  <div className="text">
                    <div className="title">{insuranceType.label}</div>
                    {
                      insuranceType?.description?.length > 0 && (
                        <div className="description">{insuranceType.description}</div>
                      )
                    }
                  </div>
                  <div className="icons">
                    {
                      insuranceType.value === 'Bundle' ? (
                        <>
                          <Image preview={false} src={insuranceType.icons[0].src} alt="" />
                          {' + '}
                          <Image preview={false} src={insuranceType.icons[1].src} alt="" />
                        </>
                      ) : (
                        <Image preview={false} src={insuranceType.icons[0].src} alt="" />
                      )
                    }
                  </div>
                </div>
              </Checkbox>
            </Col>
          </Fragment>
        ))
      }
    </Row>
  );
}

Module.propTypes = {
  current: string,
  insuranceTypes: arrayOf(shape({})).isRequired,
  onSelected: func.isRequired,
};

Module.defaultProps = {
  current: '',
};

export default Module;
