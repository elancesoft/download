import React, { useState } from "react";
import { Input } from "antd";
import PlacesAutocomplete from "react-places-autocomplete";

const styleActive = {};
const styleNormal = {};

// eslint-disable-next-line react/prop-types
function Module({
  address,
  onAddressSelect,
  placeholder,
  selectWhenChange = false,
}) {
  const [currentAddress, setCurrentAddress] = useState(address);

  const handleAddressChanged = (newAddressSearch) => {
    setCurrentAddress(newAddressSearch);
    if (selectWhenChange) {
      onAddressSelect(newAddressSearch);
    }
  };

  const handleAddressSelected = (newAddress) => {
    setCurrentAddress(newAddress);
    onAddressSelect(newAddress);
  };

  return (
    <PlacesAutocomplete
      onChange={handleAddressChanged}
      onSelect={handleAddressSelected}
      value={currentAddress}
    >
      {({ getInputProps, getSuggestionItemProps, suggestions, loading }) => (
        <>
          <Input
            {...getInputProps({
              id: "address-input",
            })}
            placeholder={placeholder}
            value={currentAddress}
          />
          <div className="autocomplete-dropdown-container">
            {loading ? <div>Loading...</div> : null}
            {suggestions.map((suggestion) => {
              const className = suggestion.active
                ? "suggestion-item-active"
                : "suggestion-item";
              const style = suggestion.active ? styleActive : styleNormal;

              const suggestionProps = {
                ...getSuggestionItemProps(suggestion, {
                  className,
                  style,
                }),
              };

              return (
                <div {...suggestionProps} key={suggestion.id}>
                  <div>{suggestion.description}</div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </PlacesAutocomplete>
  );
}

export default Module;
