import classNames from 'classnames';
import {
  node, arrayOf, func, oneOfType, string,
} from 'prop-types';
import Script from 'next/script';
import { Layout } from 'antd';
import getConfig from 'next/config';

import ModuleHead from '../../common/head-component';

const {
  publicRuntimeConfig: {
    GOOGLE_MAPS_API_KEY,
  },
} = getConfig();

function LayoutComponent({ children, pageClassname }) {
  const layoutClassname = classNames({
    'layout-application': true,
    [pageClassname]: true,
  });

  return (
    <Layout className={layoutClassname}>
      <ModuleHead />
      <Script src={`https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places`} />
      {children}
    </Layout>
  );
}

LayoutComponent.propTypes = {
  children: oneOfType([node, arrayOf(node), func]).isRequired,
  pageClassname: string,
};

LayoutComponent.defaultProps = {
  pageClassname: '',
};

export default LayoutComponent;
