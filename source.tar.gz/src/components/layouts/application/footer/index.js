function Module() {
  return (
    <div>
      Application Layout Header
    </div>
  );
}

export default Module;
