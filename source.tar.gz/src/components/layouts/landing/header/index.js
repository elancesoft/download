import Link from 'next/link';
import { useRouter } from 'next/router';
import { Button, Popover } from 'antd';
import { RightOutlined, CaretDownOutlined } from '@ant-design/icons';

const menus = [
  {
    id: 1,
    name: 'Home',
    url: '/',
  },
  {
    id: 2,
    name: 'Pricing',
    url: '/pricing',
  },
  {
    id: 3,
    name: 'For Agents',
    url: '#',
    children: [
      {
        id: 3,
        name: 'Individuals',
        url: '/individuals',
      },
      {
        id: 4,
        name: 'Sales Teams',
        url: '/sales-teams',
      },
      {
        id: 5,
        name: 'Campaigns',
        url: '/campaigns',
      },
    ],
  },
  // {
  //   id: 6,
  //   name: 'Application',
  //   url: '/f/tuanpv',
  // },
];

function Module() {
  const router = useRouter();

  return (
    <div className='landing-header'>
      <div className='links'>
        {menus.map((menu) =>
          menu?.children?.length > 0 ? (
            <Popover
              overlayClassName='landing-header-popover'
              placement='bottomLeft'
              content={() => (
                <div className='submenu'>
                  {menu?.children?.length > 0 &&
                    menu.children.map((item) => (
                      <Link key={item.id} href={item.url}>
                        <a
                          className={`item ${
                            router.pathname === item.url ? 'active' : ''
                          }`}
                        >
                          {item.name}
                        </a>
                      </Link>
                    ))}
                </div>
              )}
              trigger='click'
            >
              <Button
                className={`item has-children ${
                  menu.children.some((child) => child.url === router.pathname)
                    ? 'active'
                    : ''
                }`}
                type='link'
              >
                {menu.name} <CaretDownOutlined />
              </Button>
            </Popover>
          ) : (
            <Link key={menu.id} href={menu.url} passHref>
              <a
                className={`item ${
                  router.pathname === menu.url ? 'active' : ''
                }`}
              >
                {menu.name}
              </a>
            </Link>
          )
        )}
      </div>

      {/*<div className="actions">*/}
      {/*  <Button className="button-demo">*/}
      {/*    demo*/}
      {/*    <RightOutlined />*/}
      {/*  </Button>*/}
      {/*</div>*/}
    </div>
  );
}

export default Module;
