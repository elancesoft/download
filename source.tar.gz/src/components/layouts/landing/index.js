import classNames from 'classnames';
import {
  node, arrayOf, func, oneOfType, string,
} from 'prop-types';

import { Layout } from 'antd';

import ModuleHeader from './header';
import ModuleHead from '../../common/head-component';

function LayoutComponent({ children, pageClassname }) {
  const layoutClassname = classNames({
    'layout-landing': true,
    [pageClassname]: true,
  });

  return (
    <Layout className={layoutClassname}>
      <ModuleHead />
      <ModuleHeader />
      {children}
      {/* <ModuleFooter/> */}
    </Layout>
  );
}

LayoutComponent.propTypes = {
  children: oneOfType([node, arrayOf(node), func]).isRequired,
  pageClassname: string,
};

LayoutComponent.defaultProps = {
  pageClassname: '',
};

export default LayoutComponent;
