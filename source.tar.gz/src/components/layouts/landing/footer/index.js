function Module() {
  return (
    <div>
      Landing Layout Footer
    </div>
  );
}

export default Module;
