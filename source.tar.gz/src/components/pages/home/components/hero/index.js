import {
  Row, Col, Button, Image,
} from 'antd';
import { RightOutlined } from '@ant-design/icons';
import { useRouter } from 'next/router';

function Module() {
  const router = useRouter();

  const onPricingClicked = () => {
    router.push('/pricing');
  };

  return (
    <section className="hero">
      <div className="">
        <Row
          gutter={[
            48, {
              xs: 36, md: 48,
            },
          ]}
        >
          <Col className="text" xs={24} lg={12}>
            <h1 className="title">
              Digital Quote Forms
            </h1>
            <p className="description">
              P&C agents get their own branded online quote form to gather their prospects information quickly.
            </p>
            <Button
              type="default"
              size="small"
              onClick={onPricingClicked}
            >
              Pricing
              <RightOutlined />
            </Button>
          </Col>
          <Col className="image" xs={24} lg={12}>
            <Image preview={false} src="/images/pages/home/home_hero_img_1.png" alt="" />
          </Col>
        </Row>
      </div>
    </section>
  );
}

export default Module;
