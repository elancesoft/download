import {
  Row, Col, Image,
} from 'antd';

const icons = [
  '/images/pages/home/home_sec_2_icon_1.png',
  '/images/pages/home/home_sec_2_icon_2.png',
  '/images/pages/home/home_sec_2_icon_3.png',
  '/images/pages/home/home_sec_2_icon_4.png',
  '/images/pages/home/home_sec_2_icon_5.png',
  '/images/pages/home/home_sec_2_icon_6.png',
];

function Module() {
  return (
    <section className="services">
      <div className="container">
        <Row
          className="list"
          gutter={[
            48, {
              xs: 36, md: 48,
            },
          ]}
          justify="center"
        >
          {
            icons.map((icon, index) => (
              // eslint-disable-next-line react/react-in-jsx-scope
              <Col xs={24} md={8} lg={4} key={{ index }} align="center">
                <Image preview={false} src={icon} alt="" />
              </Col>
            ))
          }
        </Row>
      </div>
    </section>
  );
}

export default Module;
