import { Row, Col, Form, Input, Select, Button, Modal } from 'antd';
import { RightOutlined } from '@ant-design/icons';
import { useFormik } from 'formik';
import { object, string } from 'yup';
import { useState, useEffect } from 'react';

const phoneRegExp =
  /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;

const linkValues = ['1', '2', '3', '4', '5-10', '10-20', '20+'];

const srcImages = [
  '/images/pages/home/home-screen.png',
  '/images/pages/home/property-screen.png',
  '/images/pages/home/risk-score-screen.png',
];

function Module() {
  const [imageActive, setImageActive] = useState(0);
  const [isOpenModal, setOpenModal] = useState(false);

  const formik = useFormik({
    initialValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      basicurls: '',
      links: '',
    },
    validationSchema: object({
      firstName: string().required('First name is required'),
      lastName: string().required('Last name is required'),
      email: string().required('Email is required').email('Email is not valid'),
      phone: string()
        .required('Phone number is required')
        .matches(phoneRegExp, 'Phone number is not valid'),
      basicurls: string().required('Unique Label is required'),
      links: string().required('Links is required'),
    }),
    onSubmit: (values) => {
      console.log(values);
      setOpenModal(true);
    },
  });

  useEffect(() => {
    const autoChangeImage = setInterval(() => {
      setImageActive((imageActive) => (imageActive + 1) % srcImages.length);
    }, 3000);
    return () => clearInterval(autoChangeImage);
  }, []);

  return (
    <section className='signup-banner'>
      <div className='container'>
        <div className='text'>
          <h1 className='title'>InsurTech your agency in 5 mins!</h1>
          <p className='description'>
            Get your own branded online application for your agency or each
            producer.{' '}
          </p>
        </div>
        <Row gutter={[48, 36]}>
          <Col xs={24} lg={12} xl={8}>
            <Form
              className='signup-form'
              onFinish={formik.handleSubmit}
              layout='vertical'
            >
              <h2>Instant Free Trial</h2>
              <Form.Item
                validateStatus={formik.errors.firstName && 'error'}
                help={formik.errors.firstName}
              >
                <Input
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  name='firstName'
                  value={formik.values.firstName}
                  errors={formik.errors.firstName}
                  placeholder='First Name'
                ></Input>
              </Form.Item>
              <Form.Item
                validateStatus={formik.errors.lastName && 'error'}
                help={formik.errors.lastName}
              >
                <Input
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  name='lastName'
                  value={formik.values.lastName}
                  errors={formik.errors.lastName}
                  placeholder='Last Name'
                ></Input>
              </Form.Item>
              <Form.Item
                validateStatus={formik.errors.email && 'error'}
                help={formik.errors.email}
              >
                <Input
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  name='email'
                  value={formik.values.email}
                  errors={formik.errors.email}
                  placeholder='Email'
                ></Input>
              </Form.Item>
              <Form.Item
                validateStatus={formik.errors.phone && 'error'}
                help={formik.errors.phone}
              >
                <Input
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  name='phone'
                  value={formik.values.phone}
                  errors={formik.errors.phone}
                  placeholder='Phone'
                ></Input>
              </Form.Item>
              <Form.Item
                validateStatus={formik.errors.basicurls && 'error'}
                help={formik.errors.basicurls}
              >
                <Input
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  name='basicurls'
                  value={formik.values.basicurls}
                  errors={formik.errors.basicurls}
                  placeholder='Unique Label'
                ></Input>
              </Form.Item>
              <small>
                Your client’s will see www.apply.insure/
                <span className='text-blue'>unique label</span>.<br />
                Example www.apply.insure/<span className='text-blue'>pete</span>
              </small>
              <Form.Item
                validateStatus={formik.errors.links && 'error'}
                help={formik.errors.links}
                label={'How many links do you expect to need? *'}
              >
                <Select
                  size='large'
                  defaultValue={linkValues[0]}
                  onChange={(value) => formik.setFieldValue('links', value)}
                >
                  {linkValues.map((value, i) => (
                    <Select.Option value={value} key={i}>
                      {value}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
              <div className='button-wrapper'>
                <Button
                  className='submit-button'
                  size='large'
                  type='primary'
                  htmlType='submit'
                >
                  Submit
                </Button>
              </div>
              <p className='form-footer'>
                Upon submitting, your account will be verified and you will
                immedtiatley be sent a confirmation email so you can start using
                your link. <u>No payment nessecary at signup.</u>
              </p>
            </Form>
          </Col>
          <Col className='carousel-preview' xs={24} lg={12} xl={16}>
            {srcImages.map((image, i) => (
              <div
                className={`carousel-item ${imageActive === i ? 'active' : ''}`}
                key={i}
              >
                <img src={image} width='100%' />
              </div>
            ))}
            <div
              onClick={() =>
                setImageActive(
                  (imageActive) =>
                    (imageActive + srcImages.length - 1) % srcImages.length
                )
              }
              className='carousel-control-prev'
            ></div>
            <div
              onClick={() =>
                setImageActive(
                  (imageActive) => (imageActive + 1) % srcImages.length
                )
              }
              className='carousel-control-next'
            ></div>
          </Col>
        </Row>
      </div>
      <Modal
        className='homepage-success-modal'
        onCancel={() => setOpenModal(false)}
        title=''
        visible={isOpenModal}
        width={800}
        footer={<div />}
      >
        <div className='homepage-success-modal-content'></div>
        <p>Your account has been created.</p>
        <p>
          1. A confirmation password has been sent to your Email with your
          temporary password.
        </p>
        <p>
          2. Your custom link is http://18.232.91.105/{formik.values.basicurls}
        </p>
        <Button className='homepage-success-modal-button' type='primary'>
          Go to Dashboard
        </Button>
      </Modal>
    </section>
  );
}

export default Module;
