import { Row, Col, Image } from 'antd';

function Module() {
  return (
    <section className="get-your-apps">
      <div className="container">
        <Row>
          <Col align="center" span={24}>
            <h2 className="title">
              Get Your Apps Out There!
            </h2>
          </Col>
        </Row>
      </div>
      <Row>
        <Col align="center" span={24}>
          <Image preview={false} src="/images/pages/home/home_sec_4_img_1.png" alt="" />

        </Col>
      </Row>
    </section>
  );
}

export default Module;
