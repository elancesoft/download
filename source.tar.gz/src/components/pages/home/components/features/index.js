import {
  Row, Col,
} from 'antd';

const features = [
  {
    title: 'Fast',
    description: 'A user can provide all the information needed for a quote within 2-3 minutes from their phone. You'
      + ' will immediatley receive all your clients information via email to quote.',
  },
  {
    title: 'Custom Questions',
    description: 'While the basic app comes fully functional, you\'ll be able to add custom questions to your'
      + ' specific app.',
  },
  {
    title: 'Insure Smarter',
    description: 'We pull in many APIs such as google, realtor.com, places, and others to give your agents the best information possible.',
  },
  {
    title: 'API',
    description: 'Connect to popular carriers with API technology to turn your apps into instant quotes.',
  },
  {
    title: 'Connections',
    description: 'Connect to SalesForce, Pipedrive, Google Sheets, Zapier and more.',
  },
  {
    title: 'Tech Enabled Advisors',
    description: 'Become a tech enabled advisor that your prospective clients expect and want. Equip your sales teams with a simple tool to increase sales.',
  },
];

function Module() {
  return (
    <section className="features">
      <div className="container">
        <Row
          className="list"
          gutter={[
            48, {
              xs: 36, md: 48,
            },
          ]}
          justify="center"
        >
          {
            features.map((feature, index) => (
              // eslint-disable-next-line react/no-array-index-key
              <Col xs={24} md={24} lg={8} key={{ index }} align="center">
                <h5 className="title">
                  {feature.title}
                </h5>
                <p className="description">
                  {feature.description}
                </p>
              </Col>
            ))
          }
        </Row>
      </div>
    </section>
  );
}

export default Module;
