import { object, string, date } from 'yup';
import moment from 'moment';

const phoneRegExp = /^[+0-9 \\-]{10,13}$/;

const schemas = {
  // Form Step 1 Schema
  0: object({
    insuranceType: string().required().oneOf([
      'Home',
      'Auto',
      'Bundle',
    ]),
  }),

  // Form Step 2 Schema
  1: object({
    firstName: string().required('First name is required'),
    lastName: string().required('Last name is required'),
    dob: string().required('Date of birth is required'),
    currentAddress: string(),
  }),

  // Form Step 3 Schema
  2: object({
    email1: string().required('Email is required').email('Email is not valid'),
    email2: string().email('Email is not valid'),
    phone: string().required("Phone is required").matches(phoneRegExp, 'Phone number is not valid'),
  }),

  // Form Step 4 Schema
  3: object({
    policyStartDate: string().required('Please enter policy date or click I don\'t know'),
  }),

  // Form Step 6 Schema
  9: object({
    propertyAddress: string().required('Property address is empty!'),
  }),
};

export default schemas;
