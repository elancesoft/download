import { useRouter } from 'next/router';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Col, Row } from 'antd';

import ModuleFormHeader from './components/header';
import ModuleFormStep1 from './components/step-1';
import ModuleFormStep2 from './components/step-2';
import ModuleFormStep3 from './components/step-3';
import ModuleFormStep4 from './components/step-4';
import ModuleFormStep51 from './components/step-5-1';
import ModuleFormStep52 from './components/step-5-2';
import ModuleFormStep53 from './components/step-5-3';
import ModuleFormStep54 from './components/step-5-4';
import ModuleFormStep55 from './components/step-5-5';
import ModuleFormStep56 from './components/step-5-6';
import ModuleFormStep6 from './components/step-6';
import ModuleFormStep7 from './components/step-7';
import ModuleFormStep8 from './components/step-8';
import ModuleFormStep9 from './components/step-9';
import ModuleFormStep10 from './components/step-10';
import ModuleFormStep11 from './components/step-11';
import ModuleFormStep12 from './components/step-12';
import ModuleFormStep13 from './components/step-13';
import ModuleFormStep14 from './components/step-14';
import ModuleFormStep15 from './components/step-15';
import ModuleFormStep15New from './components/step-15-new';

import { updateQuote } from '../../../../../redux/slices/quoteRequestSlice';
import requestQuoteFormSchemas from './validationSchemas';

const steps = [
  ModuleFormStep1, /* 0  */
  ModuleFormStep2, /* 1  */
  ModuleFormStep3, /* 2  */
  ModuleFormStep4, /* 3  */
  ModuleFormStep51, /* 4  */
  ModuleFormStep52, /* 5  */
  ModuleFormStep53, /* 6  */
  ModuleFormStep54, /* 7  */
  ModuleFormStep55, /* 8  */
  ModuleFormStep56, /* 8  */
  ModuleFormStep6, /* 9  */
  ModuleFormStep7,
  ModuleFormStep8,
  ModuleFormStep9,
  ModuleFormStep10,
  ModuleFormStep11,
  ModuleFormStep12,
  ModuleFormStep13,
  ModuleFormStep14,
  ModuleFormStep15,
  // ModuleFormStep15New,
];


const renderFormStep = (step, onStepSubmitted, skipToStep) => {
  const CurrentStep = steps[step];

  if (!CurrentStep) return <div>Missing step</div>;

  return (
    <CurrentStep
      {
        ...(
          requestQuoteFormSchemas[step] ? {
            validationSchema: requestQuoteFormSchemas[step],
          } : {}
        )
      }
      skipToStep={skipToStep}
      onStepSubmitted={onStepSubmitted}
    />
  );
};

function Module() {
  const user = useSelector((state) => state?.user ?? {});
  const router = useRouter();
  const [activeStep, setActiveStep] = useState(0);
  const dispatch = useDispatch();
  const isQualifiedRiskScoreTaken = useSelector((state) => state?.quoteRequest?.isQualifiedRiskScoreTaken);

  const backToPreviousStep = () => {
    if (activeStep <= 0) router.push('/');

    let previousStep = activeStep - 1;

    if (activeStep === 10) {
      if (!isQualifiedRiskScoreTaken) {
        previousStep = 4;
      }
      if (!user.riskPage) {
        previousStep = 3;
      }
    }
    setActiveStep(previousStep);
  };

  const skipToStep = (step) => {
    setActiveStep(step);
  };

  const onStepSubmitted = (stepValues) => {
    dispatch(updateQuote(stepValues));
    const nextStep = activeStep + 1;
    setActiveStep(nextStep);
  };

  return (
    <>
      <ModuleFormHeader step={activeStep} totalSteps={steps.length} backToPreviousStep={backToPreviousStep} />
      <div className="container">
        <Row className="form-row">
          <Col xs={24}>
            {
              renderFormStep(activeStep, onStepSubmitted, skipToStep)
            }
          </Col>
        </Row>
      </div>
    </>
  );
}

export default Module;
