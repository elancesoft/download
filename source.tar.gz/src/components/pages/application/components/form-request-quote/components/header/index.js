import { useState } from 'react';
import {
  Button, Col, Image, Progress, Row, Modal,
} from 'antd';
import { useSelector } from 'react-redux';
import { LeftOutlined } from '@ant-design/icons';
import { func, number } from 'prop-types';
import getConfig from 'next/config';

import IconInfo from '../../../../../../../../public/images/pages/application/application_form_icon_info.png';
import IconPhone from '../../../../../../../../public/images/pages/application/application_header_icon_phone.svg';
import IconEnvelop from '../../../../../../../../public/images/pages/application/application_header_icon_envelop.svg';
import DefaultAvatar from '../../../../../../../../public/images/pages/application/application_header_default_avatar.png';
import DefaultNullAgencyImage from '../../../../../../../../public/images/pages/application/application_form_null_image.png';

const {
  publicRuntimeConfig: {
    BASE_IMAGE_URL,
  },
} = getConfig();

function Module({ step = 1, totalSteps, backToPreviousStep }) {
  const user = useSelector((state) => state?.user ?? {});
  const [isModalVisible, setIsModalVisible] = useState(false);

  const handleCancel = () => setIsModalVisible(false);

  const showModal = () => setIsModalVisible(true);

  return (
    <>
      <section className="application-form-request-quote-header">
        <Row justify="center">
          {step > 0 && <Button className="back-button" size="large" icon={<LeftOutlined />} onClick={backToPreviousStep} />}

          <Col xs={12} md={4} className="user-info" align="center">
            <div>Your agent:</div>
            <div>
              { `${user.firstname} ${user.lastname}` ?? ''}
              {' '}
              <Image className="form-header-icon" preview={false} src={IconInfo.src ?? ''} alt="" />
            </div>
            <a className="ant-btn ant-btn-link" onClick={showModal}>
              <Image className="form-header-user-avatar" preview={false} src={user.agentimage ? `${BASE_IMAGE_URL}/${user.agentimage}` : DefaultAvatar.src} alt="" />
            </a>
          </Col>

          <Progress percent={((step + 1) / totalSteps) * 100} status="active" showInfo={false} />
        </Row>
      </section>

      <Modal
        className="modal-user"
        onCancel={handleCancel}
        visible={isModalVisible}
        title={null}
        footer={null}
      >
        <Row justify="center">
          <Col xs={24} align="center">
            <Image className="avatar" preview={false} src={user.agentimage ? `${BASE_IMAGE_URL}/${user.agentimage}` : DefaultAvatar.src} alt="" />

            <h3 className="name">
              { `${user.firstname} ${user.lastname}` ?? ''}
            </h3>

            <div className="agencyname">
              {user.agencyname}
            </div>

            <Image className="agencyimage" preview={false} src={user.agencyimage ? `${BASE_IMAGE_URL}/${user.agencyimage}` : DefaultNullAgencyImage.src} alt="" />

            <div className="contacts">
              <div className="phone">
                <div className="icon-wrapper">
                  <Image className="icon" preview={false} src={IconPhone.src} />
                </div>
                {user.phone || ''}
              </div>
              <div className="email">
                <div className="icon-wrapper">
                  <Image className="icon" preview={false} src={IconEnvelop.src} />
                </div>
                {user.email || ''}
              </div>
            </div>

          </Col>
        </Row>
      </Modal>
    </>
  );
}

Module.propTypes = {
  step: number.isRequired,
  totalSteps: number.isRequired,
  backToPreviousStep: func.isRequired,
};

export default Module;
