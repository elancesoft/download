import { Card, Row, Col, InputNumber, Space, Spin } from "antd";
import { EditOutlined, SaveOutlined } from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import { useState, useEffect } from "react";
import { func } from "prop-types";
import { getZillow, getHippo, getFlood } from "../../../../../../../actions";
import { getAddressComponent } from "../../../../../../../utils";
import { updateApiResult } from "../../../../../../../redux/slices/apiResultSlice";
import { updateQuote } from "../../../../../../../redux/slices/quoteRequestSlice";

const buttonContents = [
  { name: "Primary Residence", iconSrc: "/images/pages/application/home.svg" },
  { name: "Vacation Home", iconSrc: "/images/pages/application/vacation.svg" },
  {
    name: "Landlord Property",
    iconSrc: "/images/pages/application/Landlord.svg",
  },
  { name: "I Rent This Home", iconSrc: "/images/pages/application/rent.svg" },
];

function Module({ onStepSubmitted }) {
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const { firstName, lastName, propertyAddress } = useSelector(
    (store) => store.quoteRequest
  );
  const user = useSelector((store) => store.user);
  const dispatch = useDispatch();
  const [errorMsg, setErrorMsg] = useState("");
  const [isLoading, setLoading] = useState(true);

  const [homeProps, setHomeProps] = useState({
    numberOfFullBathrooms: quoteRequest?.numberOfFullBathrooms || 0,
    numberOfHalfBathrooms: quoteRequest?.numberOfHalfBathrooms || 0,
    numberOfStories: quoteRequest?.numberOfStories || 0,
    garage: quoteRequest?.garage || "",
    yearBuilt: quoteRequest?.yearBuilt || 0,
    squareFeet: quoteRequest?.squareFeet || 0,
  });
  const [isEditMode, setEditMode] = useState(
    !quoteRequest?.squareFeet || !quoteRequest?.squareFeet
  );

  const updateHomeProperties = (newProperties) => {
    if (typeof newProperties !== "object") {
      return;
    }
    setHomeProps((prev) => ({ ...prev, ...newProperties }));
  };

  const handleChangeEditMode = () => {
    if (!isEditMode) {
      setEditMode(true);
    } else if (homeProps?.squareFeet <= 0 || homeProps?.yearBuilt <= 0) {
      setErrorMsg("Please input square feet and year built!");
    } else {
      setErrorMsg("");
      setEditMode(false);
    }
  };

  const handleClickButton = (index) => {
    if (index === 3 || (!isEditMode && !isLoading)) {
      onStepSubmitted({
        ...homeProps,
        selectedUserType: buttonContents[index].name,
      });
      getPriceApi();
    } else {
      setErrorMsg("Please save data!");
    }
  };

  const getPriceApi = () => {
    getAddressComponent(propertyAddress)
      .then((res) => {
        if (user?.isEnableApi) {
          const bodyHippoObject = {
            personData: [
              {
                first_name: firstName,
                last_name: lastName,
              },
            ],
            address: {
              address: res.street_number.long_name + ", " + res.route.long_name,
              locality: res.locality.long_name,
              administrative_area_level_1:
                res.administrative_area_level_1.short_name,
              postal_code: res.postal_code.long_name,
            },
            built_year: homeProps?.yearBuilt,
            sqft: homeProps?.squareFeet,
          };

          getHippo(bodyHippoObject)
            .then((res) => {
              let hippo = JSON.parse(res.data);
              let hippoHomePrice = hippo?.quote_premium || 0;
              let hippoHomeUrl = hippo?.quote_url || 0;
              let dwellingCoverageHippo = hippo.coverage_a;
              dispatch(updateApiResult({ dwellingCoverageHippo }));
              dispatch(updateQuote({ hippoHomePrice, hippoHomeUrl }));
            })
            .catch((error) => {
              console.log(error);
            });
        }

        const bodyFloodObject = {
          square: homeProps?.squareFeet,
          yearBuilt: homeProps?.yearBuilt,
          address: res.street_number.long_name + " " + res.route.long_name,
          state: res.administrative_area_level_1.short_name,
          city: res.locality.long_name,
          zip: res.postal_code.long_name,
        };

        getFlood(bodyFloodObject)
          .then((res) => {
            console.log(res);
            let floodZone =
              res.data?.neptune?.flood_zone ||
              res.data?.wright_nfip?.flood_zone ||
              "";
            dispatch(updateApiResult({ floodZone }));

            if (user?.anexflood_api?.isOn && user?.isEnableApi) {
              let annexfloodApiResult = Object.keys(res.data)
                .filter(
                  (item) =>
                    Object.keys(res.data?.[item]?.deductible)?.length > 0
                )
                .map((item) => {
                  let rsObj =
                    res.data?.[item]?.deductible[5000] ||
                    Object.values(res.data?.[item]?.deductible)[0] ||
                    {};
                  return {
                    partner: item,
                    home_price: rsObj?.premium || 0,
                    url: rsObj?.link || "",
                  };
                });
              dispatch(updateQuote({ annexfloodApiResult }));
            }
          })
          .catch(console.log);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const autoFillHouseData = () => {
    setLoading(true);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      {
        address: propertyAddress,
      },
      (results) => {
        console.log(results);
        const uluru = {
          lat: results?.[0]?.geometry?.location?.lat(),
          lng: results?.[0]?.geometry?.location?.lng(),
        };
        const map = new google.maps.Map(document.getElementById("map"), {
          zoom: 12,
          center: uluru,
          disableDefaultUI: true,
          scaleControl: false,
          draggable: false,
        });

        if (homeProps?.yearBuilt !== 0 && homeProps?.squareFeet !== 0) {
          setLoading(false);
          return;
        }

        // auto fill
        const obj = {};
        const address_components = results?.[0]?.address_components || [];
        console.log(address_components);
        for (const address of address_components) {
          if (address.types.includes("street_number")) {
            obj.street_number = address.long_name;
          }
          if (address.types.includes("route")) {
            obj.route = address.long_name;
          }
          if (address.types.includes("administrative_area_level_1")) {
            obj.state = address.short_name;
          }
          if (address.types.includes("locality")) {
            obj.locality = address.long_name;
          }
          if (address.types.includes("postal_code")) {
            obj.zip = address.long_name;
          }
        }

        getZillow({
          address: obj.street_number + " " + obj.route,
          citystatezip: obj.locality + ", " + obj.state + ", " + obj.zip,
        })
          .then((res) => {
            const { data } = res;
            const dwellingCoverageRealtor = data.price || 0;
            dispatch(updateApiResult({ dwellingCoverageRealtor }));
            updateHomeProperties({
              numberOfFullBathrooms: data?.baths_full || 0,
              numberOfHalfBathrooms: data?.baths_half || 0,
              numberOfStories: data?.stories || 0,
              garage: data?.garage || "",
              yearBuilt: data?.year_built || 0,
              squareFeet: data?.building_size || 0,
            });
            if (data.building_size && data.building_size) {
              setEditMode(false);
            }
            setLoading(false);
          })
          .catch((error) => {
            setLoading(false);
            console.log(error);
          });
      }
    );
  };

  useEffect(() => {
    autoFillHouseData();
  }, []);

  return (
    <section className="step-page-7">
      <div className="title">
        <h3>What property do you need coverage for? </h3>
      </div>
      <Card
        className="cart"
        title={
          <div className="card-head">
            <img src="/images/pages/application/locationmarker.svg" />
            <span>{propertyAddress}</span>
          </div>
        }
      >
        <div id="map">123</div>
        <Spin spinning={isLoading}>
          <div className="change-property">
            <Space size="large">
              <Space>
                {isEditMode ? (
                  <InputNumber
                    value={homeProps?.squareFeet}
                    onChange={(squareFeet) =>
                      updateHomeProperties({ squareFeet })
                    }
                  />
                ) : (
                  <span className="text text-pink">
                    {homeProps?.squareFeet}
                  </span>
                )}
                <span className="text">Square Feet</span>
              </Space>
              <Space>
                {isEditMode ? (
                  <InputNumber
                    className="input-year-built"
                    value={homeProps?.yearBuilt}
                    onChange={(yearBuilt) =>
                      updateHomeProperties({ yearBuilt })
                    }
                  />
                ) : (
                  <span className="text text-pink">{homeProps?.yearBuilt}</span>
                )}
                <span className="text">Year Built</span>
              </Space>
              <Space>
                {isEditMode ? (
                  <InputNumber
                    className="input-year-built"
                    value={homeProps?.numberOfStories}
                    onChange={(numberOfStories) =>
                      updateHomeProperties({ numberOfStories })
                    }
                  />
                ) : (
                  <span className="text text-pink">{homeProps?.numberOfStories}</span>
                )}
                <span className="text">Stories</span>
              </Space>
            </Space>
            <div
              className="change-property-action"
              onClick={handleChangeEditMode}
            >
              {isEditMode ? <SaveOutlined /> : <EditOutlined />}
            </div>
          </div>
        </Spin>
        {errorMsg && <p className="message-error shake">{errorMsg}</p>}
      </Card>
      <Row gutter={[12, 12]} className="detail-button">
        {buttonContents.map((item, i) => (
          <Col xs={12} md={6} key={i}>
            <Card
              className={
                quoteRequest?.selectedUserType === item.name ? "active" : ""
              }
              onClick={() => handleClickButton(i)}
            >
              <img src={item.iconSrc} />
              <p>{item.name}</p>
            </Card>
          </Col>
        ))}
      </Row>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
