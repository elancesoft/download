import { Card, Row, Col, Input, Button, Image } from "antd";
import { useSelector } from "react-redux";
import { useEffect, useRef, useState } from "react";
import { func } from "prop-types";
import Slider from "react-slick";
import { getImage } from "../../../../../../../utils/string";

const defaultImage =
  "/images/pages/application/House&Person_v1_transparent.svg";

const foundationOptions = ["Basement", "Slab", "Other"];
const basementStatusOptions = ["Finished", "Unfinished"];
const constructionTypeOptions = [
  { name: "Frame" },
  { name: "Masonry" },
  { name: "Concrete" },
  { name: "Steel" },
  { name: "Log" },
  { name: "Other" },
];
const securitySystemOptions = ["Monitored", "Cameras", "None"];
const dogOptions = [
  { name: "Yes", value: true },
  { name: "No", value: false },
];
const sidingTypeOptions = [
  { name: "Vinyl", constructionNotAllowed: ["Masonry"] },
  { name: "Aluminum", constructionNotAllowed: ["Masonry"] },
  { name: "Stucco" },
  { name: "Brick" },
  { name: "Stone" },
  { name: "Wood", constructionNotAllowed: ["Masonry"] },
  { name: "Other" },
];
const heatSourceOptions = [
  "Central Gas",
  "Central Electric",
  "Central Oil",
  "Other",
  "None",
  "I don't know",
];
const shapeOfRoofOptions = ["Peaked", "Flat"];
const ageOfRoofOptions = ["1-5 yr", "5-20 yr", "20+ yr"];
const roofTypeOptions = [
  {
    name: "Asphalt shingle",
    image: "/images/pages/application/roof_type/asphalt_shingle.png",
  },
  {
    name: "Wood shingle",
    image: "/images/pages/application/roof_type/wood_shingle.png",
  },
  {
    name: "Slate roof",
    image: "/images/pages/application/roof_type/slate_roof.png",
  },
  { name: "Rubber", image: "/images/pages/application/roof_type/rubber.png" },
  {
    name: "Concrete Tile",
    image: "/images/pages/application/roof_type/concrete_tile.png",
  },
  { name: "Solar", image: "/images/pages/application/roof_type/solar.png" },
  {
    name: "Tile roof",
    image: "/images/pages/application/roof_type/tile_roof.png",
  },
  {
    name: "Tar and Gravel",
    image: "/images/pages/application/roof_type/tar_and_gravel.png",
  },
  {
    name: "Composition Shingle",
    image: "/images/pages/application/roof_type/compostion_shingle.png",
  },
];

const settings = {
  dots: true,
  infinite: false,
  speed: 500,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2,
      },
    },
  ],
};

function Module({ onStepSubmitted }) {
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const { propertyAddress } = useSelector((store) => store.quoteRequest);
  const user = useSelector((state) => state.user);
  const sliderRef = useRef(null);
  const [houseProperties, setHouseProperties] = useState({
    foundation: quoteRequest.foundation || null,
    basementStatus: quoteRequest.basementStatus || "",
    constructionType: quoteRequest.constructionType || null,
    securitySystem: quoteRequest.securitySystem || null,
    dog: typeof quoteRequest.dog === "boolean" ? quoteRequest.dog : null,
    dogDesc: quoteRequest.dogDesc || "",
    sidingType: quoteRequest.sidingType || null,
    heatSource: quoteRequest.heatSource || null,
    roofShape: quoteRequest.roofShape || null,
    roofAge: quoteRequest.roofAge || null,
    roofType: quoteRequest.roofType || null,
    claimFree: quoteRequest.claimFree || "",
  });

  const [errorMsg, setErrorMsg] = useState("");

  const handleChangeDiscountsData = (field, value) => {
    if (field === "foundation" && value !== "Basement") {
      setHouseProperties((prev) => ({
        ...prev,
        [field]: value,
        basementStatus: "",
      }));
    } else {
      console.log(field);
      console.log(value);
      setHouseProperties((prev) => ({ ...prev, [field]: value }));
    }
  };

  const handleSubmit = () => {
    console.log({ houseProperties });
    if (houseProperties.foundation == null) {
      setErrorMsg("Please select Foundation!");
      return;
    }
    if (
      houseProperties.foundation == "Basement" &&
      houseProperties.basementStatus == ""
    ) {
      setErrorMsg("Please select Basement status!");
      return;
    }
    if (houseProperties.constructionType == null) {
      setErrorMsg("Please select Construction Type!");
      return;
    }
    if (houseProperties.securitySystem == null) {
      setErrorMsg("Please select Security System!");
      return;
    }
    if (houseProperties.dog == null) {
      setErrorMsg("Please select Dog!");
      return;
    }
    if (houseProperties.dog == true && houseProperties.dogDesc.length === 0) {
      setErrorMsg("Please enter dog description!");
      return;
    }
    if (houseProperties.sidingType == null) {
      setErrorMsg("Please select Siding Type!");
      return;
    }
    if (houseProperties.heatSource == null) {
      setErrorMsg("Please select Heat Source!");
      return;
    }
    if (houseProperties.roofShape == null) {
      setErrorMsg("Please select Shape of roof!");
      return;
    }
    if (houseProperties.roofAge == null) {
      setErrorMsg("Please select Age of roof!");
      return;
    }
    if (houseProperties.roofType == null) {
      setErrorMsg("Please select Roof type!");
      return;
    }
    onStepSubmitted({ ...houseProperties });
  };

  // Scroll to selected roofType
  useEffect(() => {
    if (sliderRef?.current) {
      const selectedRoofType = roofTypeOptions.findIndex(
        (roofType) => roofType.name === houseProperties?.roofType
      );

      if (selectedRoofType >= 0) {
        sliderRef.current.slickGoTo(selectedRoofType);
      }
    }
  }, [houseProperties]);

  return (
    <section className="step-page-8">
      <Row gutter={[24, 24]}>
        <Col xs={24} md={14}>
          <div className="address-bar">
            <img src="/images/pages/application/locationmarker.svg" />
            <span>{propertyAddress}</span>
          </div>
          <div className="space">
            <Row gutter={[12, 12]} className="foundation">
              <Col xs={24} md={6}>
                <p className="label">Foundation</p>
              </Col>
              {foundationOptions.map((item, i) => (
                <Col xs={12} sm={6} key={i}>
                  <div
                    className={`select-button ${
                      houseProperties.foundation === item ? "active" : ""
                    }`}
                    onClick={() =>
                      handleChangeDiscountsData("foundation", item)
                    }
                  >
                    {item}
                  </div>
                </Col>
              ))}
            </Row>
            {houseProperties.foundation === "Basement" && (
              <div className="basement-status">
                {basementStatusOptions.map((item, i) => (
                  <Col xs={12} sm={6} key={i}>
                    <div
                      className={`select-button ${
                        houseProperties.basementStatus === item ? "active" : ""
                      }`}
                      onClick={() =>
                        handleChangeDiscountsData("basementStatus", item)
                      }
                    >
                      {item}
                    </div>
                  </Col>
                ))}
              </div>
            )}
            <Row gutter={[12, 12]} className="security-system">
              <Col xs={24} md={6}>
                <p className="label">Security System?</p>
              </Col>
              {securitySystemOptions.map((item, i) => (
                <Col xs={12} sm={6} key={i}>
                  <div
                    className={`select-button ${
                      houseProperties.securitySystem === item ? "active" : ""
                    }`}
                    onClick={() =>
                      handleChangeDiscountsData("securitySystem", item)
                    }
                  >
                    {item}
                  </div>
                </Col>
              ))}
            </Row>
            <Row gutter={[12, 12]} className="security-system">
              <Col xs={24} md={6}>
                <p className="label">Construction Type?</p>
              </Col>
              <Col xs={24} md={18}>
                <Row gutter={[12, 12]}>
                  {constructionTypeOptions.map((item, i) => (
                    <Col xs={12} sm={8} key={i}>
                      <div
                        className={`select-button ${
                          houseProperties.constructionType === item.name
                            ? "active"
                            : ""
                        }`}
                        onClick={() =>
                          handleChangeDiscountsData(
                            "constructionType",
                            item.name
                          )
                        }
                      >
                        {item.name}
                      </div>
                    </Col>
                  ))}
                </Row>
              </Col>
            </Row>
            <Row gutter={[12, 12]} className="dog-questions">
              <Col xs={24} md={6}>
                <p className="label">Dog?</p>
              </Col>
              {dogOptions.map((item, i) => (
                <Col xs={12} sm={6} key={i}>
                  <div
                    className={`select-button ${
                      houseProperties.dog === item.value ? "active" : ""
                    }`}
                    onClick={() => handleChangeDiscountsData("dog", item.value)}
                  >
                    {item.name}
                  </div>
                </Col>
              ))}
              {houseProperties.dog === true && (
                <Col xs={12} sm={6}>
                  <Input
                    value={houseProperties.dogDesc}
                    onChange={(e) =>
                      handleChangeDiscountsData("dogDesc", e.target.value)
                    }
                    placeholder="Description"
                  />
                </Col>
              )}
            </Row>
            <Row gutter={[12, 12]} className="roof-age">
              <Col xs={24} md={6}>
                <p className="label">Siding Type?</p>
              </Col>
              <Col xs={24} md={18}>
                <Row gutter={[12, 12]}>
                  {sidingTypeOptions.map((item, i) => (
                    <Col xs={12} sm={8} key={i}>
                      <button
                        className={`select-button ${
                          houseProperties.sidingType === item.name
                            ? "active"
                            : ""
                        }`}
                        onClick={() =>
                          handleChangeDiscountsData("sidingType", item.name)
                        }
                        disabled={item?.constructionNotAllowed?.includes(
                          houseProperties?.constructionType
                        )}
                      >
                        {item.name}
                      </button>
                    </Col>
                  ))}
                </Row>
              </Col>
            </Row>
            <Row gutter={[12, 12]} className="roof-age">
              <Col xs={24} md={6}>
                <p className="label">Heat Source?</p>
              </Col>
              <Col xs={24} md={18}>
                <Row gutter={[12, 12]}>
                  {heatSourceOptions.map((item, i) => (
                    <Col xs={12} sm={8} key={i}>
                      <div
                        className={`select-button ${
                          houseProperties.heatSource === item ? "active" : ""
                        }`}
                        onClick={() =>
                          handleChangeDiscountsData("heatSource", item)
                        }
                      >
                        {item}
                      </div>
                    </Col>
                  ))}
                </Row>
              </Col>
            </Row>
            <Row gutter={[12, 12]} className="roof-age">
              <Col xs={24} md={6}>
                <p className="label">Roof Shape?</p>
              </Col>
              {shapeOfRoofOptions.map((item, i) => (
                <Col xs={12} sm={6} key={i}>
                  <div
                    className={`select-button ${
                      houseProperties.roofShape === item ? "active" : ""
                    }`}
                    onClick={() => handleChangeDiscountsData("roofShape", item)}
                  >
                    {item}
                  </div>
                </Col>
              ))}
            </Row>
            <Row gutter={[12, 12]} className="roof-age">
              <Col xs={24} md={6}>
                <p className="label">Age of roof?</p>
              </Col>
              {ageOfRoofOptions.map((item, i) => (
                <Col xs={12} sm={6} key={i}>
                  <div
                    className={`select-button ${
                      houseProperties.roofAge === item ? "active" : ""
                    }`}
                    onClick={() => handleChangeDiscountsData("roofAge", item)}
                  >
                    {item}
                  </div>
                </Col>
              ))}
            </Row>
            <Row gutter={[12, 12]} className="roof-type">
              <Col xs={24} md={6}>
                <p className="label">Roof type?</p>
              </Col>
              <Col xs={24} sm={18}>
                <Slider ref={sliderRef} {...settings} className="slick">
                  {roofTypeOptions.map((item, i) => (
                    <div
                      key={i}
                      className={`select-button select-roof-type ${
                        houseProperties.roofType === item.name ? "active" : ""
                      }`}
                      onClick={() =>
                        handleChangeDiscountsData("roofType", item.name)
                      }
                    >
                      <div>{item.name}</div>
                      <img src={item.image} alt="" />
                    </div>
                  ))}
                </Slider>
              </Col>
            </Row>
          </div>
          {errorMsg && <p className="message-error shake">{errorMsg}</p>}
          <Button className="form-submit-button" onClick={handleSubmit}>
            Continue
            <img
              src="/images/pages/application/application_form_icon_arrow_right.svg"
              alt=""
            />
          </Button>
        </Col>
        <Col xs={24} md={10}>
          <Image
            preview={false}
            src={getImage(user?.propertyimage) || defaultImage}
          />
        </Col>
      </Row>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
