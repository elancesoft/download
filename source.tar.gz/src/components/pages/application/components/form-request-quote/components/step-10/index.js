import {
  Row,
  Col,
  Input,
  Button,
  DatePicker,
  Switch,
  Spin,
  Select,
  message,
} from "antd";
import { CloseOutlined } from "@ant-design/icons";
import { useSelector, useDispatch } from "react-redux";
import { useState, useEffect, Fragment } from "react";
import { func, shape } from "prop-types";
import {
  addSelectCar,
  removeSelectCar,
  toggleOnDriver,
  toggleOffDriver,
  toggleOnCar,
  toggleOffCar,
} from "redux/slices/branchSlice";
import { updateQuote } from "redux/slices/quoteRequestSlice";
import {
  getNationwide,
  getTravelerHome,
  getAAAHome,
  getEthosLife,
  submitFormApply,
} from "actions";
import { getAddressComponent } from "utils";
import useRequestBody from "hooks/useRequestBody";

import moment from "moment";

// const initPersonData = {
//   firstName: '',
//   lastName: '',
//   birthday: '',
//   license: '',
// };

const dateFormat = "MM-DD-YYYY";

function Module({ onStepSubmitted }) {
  // To prefill step 2 data into step 10 members list
  const quoteRequest = useSelector((state) => state?.quoteRequest ?? {});
  const apiResult = useSelector((state) => state?.apiResult ?? {});
  const { selectedCars } = useSelector((store) => store.branch);
  const user = useSelector((store) => store.user);
  const { householdCars } = quoteRequest;
  const { nationwideHomeBody, travelerHomeBody, aaaHomeBody } =
    useRequestBody();

  const initPersonData = {
    firstName: quoteRequest?.firstName,
    lastName: quoteRequest?.lastName,
    birthday: quoteRequest?.dob,
    license: "",
    gender: "",
    relation: "Primary",
  };
  const personDataStore = quoteRequest?.householdMembers;

  const { drivers, cars } = useSelector((store) => store?.branch);
  const dispatch = useDispatch();
  const [persons, setPersons] = useState(
    personDataStore ? [...personDataStore] : [{ ...initPersonData }]
  );
  const [submitValue, setSubmitValue] = useState(null);
  const [isError, setError] = useState(false);

  const handleChangePersonData = (index, field, value) => {
    const clonedPersons = persons.map((person) => ({ ...person }));
    clonedPersons[index][field] = value;
    setPersons(clonedPersons);
    // console.log(field);
    // console.log(value);
    // setPersons((prev) => prev.map((item, i) => {
    //   if (i === index) {
    //     item[field] = value;
    //   }
    //   return item;
    // }));
  };

  const handleChangePersonSwitch = (person, isToggleOn) => {
    if (isToggleOn) {
      dispatch(toggleOnDriver(person));
      // check person exist
      for (const p of persons) {
        if (p?.id === person.id) {
          return;
        }
      }
      let date = new Date();
      date.setFullYear(date.getFullYear() - person.age || 0);
      setPersons([
        ...persons,
        {
          id: person.id,
          firstName: person.firstName,
          lastName: person.lastName,
          birthday: person.age ? date.toISOString() : "",
          license: "",
          gender: person?.gender === "F" ? "Female" : "Male",
          relation: "",
        },
      ]);
    } else {
      dispatch(toggleOffDriver(person));
      setPersons((persons) => persons.filter((item) => item?.id !== person.id));
    }
  };

  const handleChangeCarSwitch = (car, isToggleOn) => {
    if (isToggleOn) {
      dispatch(addSelectCar(car));
      dispatch(toggleOnCar(car));
    } else {
      dispatch(removeSelectCar(car));
      dispatch(toggleOffCar(car));
    }
  };

  const addNewMember = () => {
    if (persons.length >= 7) {
      return;
    }
    let relation = persons.length === 0 ? "Primary" : "";
    setPersons((prev) => [
      ...prev,
      {
        firstName: "",
        lastName: "",
        birthday: "",
        license: "",
        gender: "",
        relation: relation,
      },
    ]);
  };

  const removeMember = (index) => {
    dispatch(toggleOffDriver(persons?.[index]));
    setPersons((prev) => prev.filter((item, i) => i !== index));
  };

  const handleSubmit = () => {
    for (const person of persons) {
      if (
        person.firstName?.length === 0 ||
        person.lastName?.length === 0 ||
        person.birthday?.length === 0 ||
        person.gender?.length === 0 ||
        person.relation?.length === 0
      ) {
        setError(true);
        return;
      }
    }

    onStepSubmitted({
      householdMembers: persons,
      householdCars: householdCars?.length > 0 ? householdCars : selectedCars,
    });

    if (user?.isEnableApi) {
      getPriceApi();
    }
  };

  const getPriceApi = () => {
    getAddressComponent(quoteRequest.propertyAddress)
      .then((res) => {
        if (user?.nationwide_api?.isOn) {
          getNationwide(nationwideHomeBody()) // home
            .then((res) => {
              console.log("nationwide_home", res.data);
              let nationwideHomePrice = res.data?.homePrice || 0;
              dispatch(updateQuote({ nationwideHomePrice }));
            })
            .catch((error) => {
              dispatch(updateQuote({ nationwideHomePrice: 0 }));
              console.log("nationwide_home error", error);
            });
        }

        if (user?.traveler_api?.isOn) {
          getTravelerHome(travelerHomeBody({ drivers })) // home
            .then((res) => {
              let travelerHomePrice =
                +res.data?.homePrice ||
                +res.data?.result?.IntegratedPartnerHomeQuoteResponse
                  ?.IntegratedPartnerHomeQuoteOutput?.[0]?.Output?.[0]
                  ?.ACORD?.[0]?.InsuranceSvcRs?.[0]?.HomePolicyQuoteInqRs?.[0]
                  ?.PolicySummaryInfo?.[0]?.FullTermAmt?.[0]?.Amt?.[0] ||
                0;
              let travelerHomeUrl =
                res.data?.homeUrl ||
                res.data?.result?.IntegratedPartnerHomeQuoteResponse
                  ?.IntegratedPartnerHomeQuoteOutput?.[0]?.Output?.[0]
                  ?.ACORD?.[0]?.InsuranceSvcRs?.[0]
                  ?.HomePolicyQuoteInqRs?.[0]?.[
                  "com.travelers_NextActionsAvailable"
                ]?.[0]?.Actions?.[0]?.Action?.[0]?.ActionURL?.[0];
              console.log("traveler_home", travelerHomePrice, res.data);
              dispatch(updateQuote({ travelerHomePrice, travelerHomeUrl }));
            })
            .catch((error) => {
              dispatch(updateQuote({ travelerHomePrice: 0 }));
              console.log("traveler_home error", error);
            });
        }

        if (user?.aaa_api?.isOn) {
          getAAAHome(aaaHomeBody()) // home
            .then((res) => {
              console.log("aaa_home", res.data);
              let aaaHomePrice = +res.data?.homePrice || 0;
              let aaaHomeUrl =
                res.data?.homeUrl || res.data?.result?.provider?.URLs?.URL;
              dispatch(updateQuote({ aaaHomePrice, aaaHomeUrl }));
            })
            .catch((error) => {
              dispatch(updateQuote({ aaaHomePrice: 0 }));
              console.log("aaa_home error", error);
            });
        }

        if (user?.ethoslife_api?.isOn) {
          let personSatify = persons.filter(
            (item) =>
              new Date().getFullYear() -
                new Date(item?.birthday).getFullYear() >
              20
          );
          Promise.all(
            personSatify.map((item) =>
              getEthosLife({
                birthday: moment(item.birthday).format("YYYY-MM-DD"),
                gender: item.gender,
                state: res.administrative_area_level_1.short_name,
              })
            )
          ).then((res) => {
            console.log("ethos life res", res);
            let ethosLifeApiResult = res.map((item, i) => ({
              name: personSatify[i].firstName + " " + personSatify[i].lastName,
              price: item.data.price || 0,
              url: item.data.url || "",
            }));
            dispatch(updateQuote({ ethosLifeApiResult }));
          });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    let nextPage = true;

    if (user?.nationwide_api?.isOn) {
      nextPage = nextPage && typeof apiResult.nationwideHomePrice === "number";
    }
    if (user?.traveler_api?.isOn) {
      nextPage = nextPage && typeof apiResult.travelerHomePrice === "number";
    }
    if (user?.aaa_api?.isOn) {
      nextPage = nextPage && typeof apiResult.aaaHomePrice === "number";
    }
    // if (submitValue && nextPage) {
    //   onStepSubmitted(submitValue);
    // }
  }, [submitValue, apiResult]);

  return (
    <section className="step-page-10">
      {drivers.length > 0 && cars.length > 0 && (
        <>
          <div className="house-hold-title">
            <h3 className="title">House Hold</h3>
          </div>{" "}
          <Row className="house-hold-content" gutter={32}>
            <Col xs={24} md={10}>
              <Row>
                <Col xs={12}>
                  <p className="subtitle">Possible Members</p>
                </Col>
                <Col xs={12}>
                  <p className="subtitle">Age</p>
                </Col>
                {drivers?.map((item, i) => (
                  <Fragment key={i}>
                    <Col xs={2}>
                      <img src="/images/pages/application/household_person.svg" />
                    </Col>
                    <Col xs={10}>{`${item?.firstName} ${item?.lastName}`}</Col>
                    <Col xs={8}>{item?.age}</Col>
                    <Col xs={4}>
                      <Switch
                        size="small"
                        defaultChecked={item?.isToggleOn}
                        onChange={(value) =>
                          handleChangePersonSwitch(item, value)
                        }
                      />
                    </Col>
                  </Fragment>
                ))}
              </Row>
            </Col>
            <Col xs={24} md={14}>
              <p className="subtitle">
                Quick Bundle Estimate{" "}
                <span>(about 80%+ bundle to save more)</span>
              </p>
              <Row>
                {cars?.map((item, i) => (
                  <Fragment key={i}>
                    <Col xs={2}>
                      <img src="/images/pages/application/household_car.svg" />
                    </Col>
                    <Col xs={10}>{item.model}</Col>
                    <Col xs={8}>{item.VIN}</Col>
                    <Col xs={4}>
                      <Switch
                        size="small"
                        defaultChecked={item?.isToggleOn}
                        onChange={(value) => handleChangeCarSwitch(item, value)}
                      />
                    </Col>
                  </Fragment>
                ))}
              </Row>
            </Col>
          </Row>
        </>
      )}
      <div className="title">
        <h3>Household Members </h3>
      </div>
      {persons.map((item, i) => (
        <Row key={i} gutter={[16, 16]} className="member-row">
          <Col xs={12} sm={8} lg={5}>
            <Input
              value={item.firstName}
              size="large"
              placeholder="First Name*"
              onChange={(e) =>
                handleChangePersonData(i, "firstName", e.target.value)
              }
            />
          </Col>
          <Col xs={12} sm={8} lg={5}>
            <Input
              value={item.lastName}
              size="large"
              placeholder="Last Name*"
              onChange={(e) =>
                handleChangePersonData(i, "lastName", e.target.value)
              }
            />
          </Col>
          <Col xs={12} sm={8} lg={4}>
            <DatePicker
              size="large"
              value={item.birthday ? moment(item.birthday) : ""}
              format={dateFormat}
              placeholder="Date of birth*"
              onChange={(e) =>
                handleChangePersonData(i, "birthday", e.toISOString())
              }
              onBlur={(e) => {
                if (
                  moment(e.target?.value, dateFormat).isValid() &&
                  e.target.value?.length >= 8
                ) {
                  const utcDate = moment(e.target?.value, dateFormat)
                    .utc()
                    .toString();
                  handleChangePersonData(i, "birthday", utcDate);
                }
              }}
              style={{ width: "100%" }}
            />
          </Col>
          <Col xs={12} sm={8} lg={3}>
            <Select
              size="large"
              defaultValue={item.gender || null}
              placeholder="Gender"
              onChange={(value) => handleChangePersonData(i, "gender", value)}
              style={{ width: "100%" }}
            >
              {["Male", "Female"].map((item, j) => (
                <Select.Option value={item} key={j}>
                  {item}
                </Select.Option>
              ))}
            </Select>
          </Col>
          <Col xs={12} sm={8} lg={3}>
            <Select
              size="large"
              defaultValue={item.relation || null}
              placeholder="Relation"
              onChange={(value) => handleChangePersonData(i, "relation", value)}
              style={{ width: "100%" }}
            >
              {i === 0 && (
                <Select.Option value="Primary">Primary</Select.Option>
              )}
              {["Spouse", "Child", "Partner", "Relative", "Non - relative"].map(
                (item, j) => (
                  <Select.Option value={item} key={j}>
                    {item}
                  </Select.Option>
                )
              )}
            </Select>
          </Col>
          <Col xs={12} sm={8} lg={4}>
            <Input
              value={item.license}
              size="large"
              placeholder="Driver Licence"
              onChange={(e) =>
                handleChangePersonData(i, "license", e.target.value)
              }
            />
          </Col>
          {persons.length > 1 && (
            <div
              className="remove-member-button"
              onClick={() => removeMember(i)}
            >
              <CloseOutlined />
            </div>
          )}
        </Row>
      ))}
      {persons.length < 7 && (
        <Button className="add-button" onClick={addNewMember}>
          ADD +
        </Button>
      )}
      {isError && (
        <p className="message-error shake">Please enter all required fields.</p>
      )}

      <Spin spinning={false} delay={500} style={{ width: "24.8rem" }}>
        <Button
          className="form-submit-button"
          disabled={false}
          onClick={handleSubmit}
        >
          Continue
          <img
            src="/images/pages/application/application_form_icon_arrow_right.svg"
            alt=""
          />
        </Button>
      </Spin>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
