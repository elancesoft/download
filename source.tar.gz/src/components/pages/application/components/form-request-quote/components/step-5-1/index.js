import React, { useEffect } from 'react';
import { useSelector } from "react-redux";
import {
  Image, Button, Row, Col,
} from 'antd';
import { func } from 'prop-types';
import IconQuantify from '../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg';
import IconSettings from '../../../../../../../../public/images/pages/application/application_form_icon_settings.svg';
import IconArrowRight from '../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg';

function Module({ onStepSubmitted, skipToStep }) {
  const user = useSelector((state) => state?.user ?? {});
  const continueQualifyRiskScore = () => onStepSubmitted({
    isQualifiedRiskScoreTaken: true,
  });
  const skipQualifyRiskScore = () => skipToStep(10);

  useEffect(() => {
    console.log(user.riskPage, user)
    if (user.riskPage !== true) {
      skipQualifyRiskScore();
    }
  });

  return (
    <Row gutter={[16, 16]} align="center" className="form-risk-score">
      <Col xs={24} md={12} align="center">
        <Image rootClassName="form-quantified-risk-icon" preview={false} src={IconQuantify.src ?? ''} alt=""/>
        <h4 className="title">
          Quantified Risk Score?
        </h4>
        <div className="description">
          Do you want to answer 3 questions to get a quick risk score to help
          {' '}
          <br/>
          us better tailor your policy? (Approx 1 min)
        </div>
        <div className="options">
          <Button className="form-submit-button style-one" onClick={continueQualifyRiskScore}>
            <Image rootClassName="form-quantified-risk-icon button-icon" preview={false} src={IconQuantify.src ?? ''} alt=""/>
            &nbsp;
            Yes
            <Image rootClassName="form-quantified-icon-settings button-icon" preview={false} src={IconSettings.src ?? ''} alt=""/>
          </Button>
          <Button className="form-submit-button" onClick={skipQualifyRiskScore}>
            Skip
            <Image rootClassName="form-quantified-icon-arrow-right button-icon" preview={false} src={IconArrowRight.src ?? ''} alt=""/>
          </Button>
        </div>
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
  skipToStep: func.isRequired,
};

export default Module;
