/* eslint-disable react/prop-types,no-underscore-dangle */
import { useFormik } from "formik";
import { Form, Input, Col, Row, Button, Image, message } from "antd";
import { useSelector, useDispatch } from "react-redux";
import { func, shape } from "prop-types";

import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import IconMail from "../../../../../../../../public/images/pages/application/application_form_icon_email.svg";
import IconPhone from "../../../../../../../../public/images/pages/application/application_form_icon_phone.svg";
import { useEffect, useState } from "react";
import { submitFormApply } from "actions";
import { updateQuote } from "redux/slices/quoteRequestSlice";

function Module({ validationSchema, onStepSubmitted }) {
  const dispatch = useDispatch();
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const user = useSelector((state) => state.user);
  const [showAdditionalEmail, setShowAdditionalEmail] = useState(false);

  const initialValues = useSelector((state) => ({
    email1: state?.quoteRequest?.emails?.[0] ?? "",
    email2: state?.quoteRequest?.emails?.[1] ?? "",
    phone: state?.quoteRequest?.phone ?? "",
  }));

  const _formik = useFormik({
    initialValues,
    validationSchema,
    // Disable valid while inputting
    validateOnChange: false,
    validateOnBlur: false,
    // Reset field's error when edited
    onChange: (event) => _formik.setFieldError(event.target.name, ""),
    onSubmit: (values) => {
      onStepSubmitted({
        phone: values.phone,
        emails: [values.email1, values.email2],
      });

      const formData = new FormData();
      formData.append(
        "data",
        JSON.stringify({
          ...quoteRequest,
          user,
          phone: values.phone,
          emails: [values.email1, values.email2],
        })
      );
      formData.append('page', '3')

      submitFormApply(formData)
        .then((res) => {
          dispatch(updateQuote({ _id: res.data._id }));
          message.success("Submited!");
        })
        .catch((error) => {
          message.error("Have an error when submit your form!");
        });
    },
  });

  const toggleSecondEmail = () => setShowAdditionalEmail(true);

  useEffect(() => {
    if (_formik.values.email2?.length > 0) {
      setShowAdditionalEmail(true);
    }
  });

  return (
    <Form
      className="form-user-info form-user-info-step-2 lg:px-16"
      onFinish={_formik.handleSubmit}
      colon={false}
    >
      <Row align="center">
        <Col xs={24} md={20}>
          <h4 className="title">Contact Info:</h4>

          <Row gutter={[{ xs: 0, md: 120 }, 0]}>
            <Col
              xs={24}
              lg={11}
              className={`group-mail ${showAdditionalEmail ? "wrap" : ""}`}
            >
              <Image
                rootClassName="form-user-info-icon"
                preview={false}
                src={IconMail.src ?? ""}
                alt=""
              />
              <Form.Item
                validateStatus={_formik.errors.email1 && "error"}
                help={_formik.errors.email1}
              >
                <Input
                  onChange={_formik.handleChange}
                  onBlur={_formik.handleBlur}
                  name="email1"
                  value={_formik.values.email1}
                  errors={_formik.errors.email1}
                  placeholder="Email Address *"
                />
              </Form.Item>
              {showAdditionalEmail && (
                <Form.Item
                  validateStatus={_formik.errors.email2 && "error"}
                  help={_formik.errors.email2}
                >
                  <Input
                    onChange={_formik.handleChange}
                    onBlur={_formik.handleBlur}
                    name="email2"
                    value={_formik.values.email2}
                    errors={_formik.errors.email2}
                    placeholder="Email Address *"
                  />
                </Form.Item>
              )}
              {!showAdditionalEmail && (
                <Button
                  onClick={toggleSecondEmail}
                  className="button-primary-one btn-add-mail"
                  type="primary"
                  size="large"
                >
                  + email
                </Button>
              )}
            </Col>

            <Col xs={24} lg={11} className="group-phone">
              <Image
                rootClassName="form-user-info-icon"
                preview={false}
                src={IconPhone.src ?? ""}
                alt=""
              />
              <Form.Item
                validateStatus={_formik.errors.phone && "error"}
                help={_formik.errors.phone}
              >
                <Input
                  onChange={_formik.handleChange}
                  onBlur={_formik.handleBlur}
                  name="phone"
                  value={_formik.values.phone}
                  errors={_formik.errors.phone}
                  placeholder="Phone number"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[16, 16]} className="actions">
            <Col xs={24} md={10}>
              <Button
                className="form-submit-button"
                onClick={_formik.handleSubmit}
              >
                Continue
                <Image
                  className="button-icon"
                  preview={false}
                  src={IconArrowRight.src ?? ""}
                  alt=""
                />
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;
