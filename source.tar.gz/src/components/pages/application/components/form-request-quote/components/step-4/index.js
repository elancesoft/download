import { useSelector } from "react-redux";
import { useFormik } from "formik";
import { Form, DatePicker, Col, Row, Button } from "antd";
import moment from "moment";
import { func, shape } from "prop-types";

const dateFormat = "MM-DD-YYYY";

function Module({ validationSchema, onStepSubmitted }) {
  const initialValues = useSelector((state) => ({
    policyStartDate: state?.quoteRequest?.policyStartDate ?? "",
  }));

  const _formik = useFormik({
    initialValues,
    validationSchema,
    // Disable valid while inputting
    validateOnChange: false,
    validateOnBlur: false,
    // Reset field's error when edited
    onChange: (event) => _formik.setFieldError(event.target.name, ""),
    onSubmit: (values) => onStepSubmitted(values),
  });

  const handleStartDateChanged = (date, dateString) => {
    _formik.setFieldError("policyStartDate", "");
    if (dateString.length > 0) {
      const utcDate = moment(dateString, dateFormat).utc().toString();
      _formik.setFieldValue("policyStartDate", utcDate);
    } else {
      _formik.setFieldValue("policyStartDate", "");
    }
  };

  const autoHandleDate = async (date, dateString) => {
    const utcDate = moment(new Date(), dateFormat)
      .add(10, "days")
      .utc()
      .toString();
    await _formik.setFieldValue("policyStartDate", utcDate);
    await _formik.submitForm();
  };

  return (
    <Form className="form-policy-start" onFinish={_formik.handleSubmit}>
      <Row gutter={[16, 16]} xs={24} justify="center">
        <Col xs={24} md={16} align="center">
          <h4 className="title">When do you want your policy to start?</h4>
          <Row gutter={[16, 16]}>
            <Col xs={18} offset={3} align="center">
              <Form.Item
                validateStatus={_formik.errors.policyStartDate && "error"}
                help={_formik.errors.policyStartDate}
              >
                <DatePicker
                  className={
                    _formik.values.policyStartDate ? "ant-picker-selected" : ""
                  }
                  onChange={handleStartDateChanged}
                  onBlur={_formik.handleBlur}
                  name="policyStartDate"
                  format={dateFormat}
                  value={
                    _formik.values.policyStartDate
                      ? moment(_formik.values.policyStartDate)
                      : ""
                  }
                  errors={_formik.errors.policyStartDate}
                  placeholder="mm-dd-yyyy *"
                  disabledDate={(current) => {
                    return moment().add(-1, "days") >= current;
                  }}
                />
              </Form.Item>
              <div className="hint">
                If you're unsure of the start date, put the closest date and we
                can change it any time
              </div>
            </Col>
          </Row>

          <Row gutter={[16, 16]} className="actions">
            <Col xs={24}>
              <Button className="form-submit-button" onClick={autoHandleDate}>
                I don't know
              </Button>
            </Col>

            <Col xs={24}>
              <Button
                className="form-submit-button"
                onClick={_formik.handleSubmit}
              >
                Continue
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;
