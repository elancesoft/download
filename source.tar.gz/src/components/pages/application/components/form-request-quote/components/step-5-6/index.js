import { Image, Button, Col, Row } from "antd";
import { func } from "prop-types";
import IconQuantify from "../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import { useSelector } from "react-redux";
import { useState } from "react";

const options = [
  "1 out of 200 Year Storm;Pay $450 per year. $200,000 Payout",
  "1 of out 100 Year Storm;Pay $1,150 per year. $200,000 payout.",
  "1 of out 75 Year Storm;Pay $3,150 per year. $400,000 payout.",
];

function Module({ onStepSubmitted }) {
  const riskSelectedOption = useSelector(
    (state) => state?.quoteRequest?.riskOption5 ?? []
  );
  const [selected, setSelected] = useState(
    typeof riskSelectedOption === "string" ? riskSelectedOption?.split("***") : []
  );

  const handleSelect = (str) => {
    let selectedClone = [...selected];
    if (selectedClone.includes(str)) {
      selectedClone.splice(selectedClone.indexOf(str), 1);
    } else {
      selectedClone.push(str);
    }
    setSelected(selectedClone);
  };

  const pickOption = (value) =>
    onStepSubmitted({ riskOption5: value.join("***") });

  return (
    <Row gutter={[16, 24]} align="center" className="form-risk-score two">
      {/* <Col xs={24} align="right">
        <Button
          className="form-submit-button skip-button"
          onClick={() => pickOption("")}
        >
          Skip
          <Image
            className="button-icon"
            preview={false}
            src={IconArrowRight.src ?? ""}
            alt=""
          />
        </Button>
      </Col> */}
      <Col xs={24} md={24} lg={18} align="center">
        <Image
          rootClassName="form-quantified-risk-icon"
          preview={false}
          src={IconQuantify.src ?? ""}
          alt=""
        />
        <h4 className="text-[30px] text-center font-semibold leading-tight">
          Which of the following scenarios would you choose to insure? (You can
          select multiple)
        </h4>
        <div className="text-[14px] text-[#00b4ff] my-[16px]">5 of 5</div>
        <div className="flex w-full -mx-2">
          {options.map((option, i) => (
            <div
              className={`flex flex-col border border-solid border-black rounded-lg mx-2 p-[16px] transition-colors cursor-pointer ${
                selected.includes(option) ? "bg-black text-white" : ""
              }`}
              onClick={() => handleSelect(option)}
            >
              <p className="text-[24px] text-blue-500 font-semibold">
                {["A", "B", "C"][i]}.
              </p>
              <p className="max-w-[120px] mt-4 pb-2 mx-auto">
                {option.split(";")[0]}
              </p>
              <hr />
              <p className="w-4/5 mt-3 mx-auto">{option.split(";")[1]}</p>
              <div className="grid grid-cols-[repeat(20,minmax(0,1fr))] gap-1 mt-4 mb-10">
                {[...new Array([200, 100, 75][i])].map((item, i) => (
                  <img
                    className="w-full"
                    src={`/images/icons/home-${i === 66 ? "red" : "gray"}.svg`}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className=" mt-20 mx-auto">
          <div
            className={`w-full h-16 max-w-md border border-solid leading-[4rem] border-black rounded-lg transition-colors hover:bg-black hover:text-white cursor-pointer`}
            onClick={() => pickOption(selected)}
          >
            Next
          </div>
        </div>
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
