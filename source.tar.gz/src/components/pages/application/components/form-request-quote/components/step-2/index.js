/* eslint-disable react/prop-types,no-underscore-dangle */
import { useFormik } from "formik";
import {
  Form,
  Input,
  DatePicker,
  Col,
  Row,
  Button,
  Image,
  message,
} from "antd";
import moment from "moment";
import { useSelector, useDispatch } from "react-redux";
import { func, shape } from "prop-types";

import IconUser from "../../../../../../../../public/images/pages/application/application_form_icon_user.svg";
import IconAddress from "../../../../../../../../public/images/pages/application/application_form_icon_address.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";

import LocationSearchInput from "../../../../../../common/location-search-input";

import { updateQuote } from "../../../../../../../redux/slices/quoteRequestSlice";
import { getBranch } from "../../../../../../../actions";
import { updateBranchByApiResponse } from "../../../../../../../redux/slices/branchSlice";
import { getAddressComponent } from "../../../../../../../utils";
import { updateApiResult } from "redux/slices/apiResultSlice";

const dateFormat = "MM-DD-YYYY";

function Module({ validationSchema, onStepSubmitted }) {
  const initialValues = useSelector((state) => ({
    firstName: state?.quoteRequest?.firstName ?? "",
    lastName: state?.quoteRequest?.lastName ?? "",
    dob: state?.quoteRequest?.dob ?? "",
    currentAddress: state?.quoteRequest?.currentAddress ?? "",
  }));
  const dispatch = useDispatch();

  const _formik = useFormik({
    initialValues,
    validationSchema,
    // Disable valid while inputting
    validateOnChange: false,
    validateOnBlur: false,
    // Reset field's error when edited
    onChange: (event) => _formik.setFieldError(event.target.name, ""),
    onSubmit: (values) => {
      onStepSubmitted(values);
      getAddressComponent(values.currentAddress)
        .then((res) => {
          dispatch(updateApiResult({ mailingAddressComponent: res }));
          const searchObject = {
            fname: values.firstName,
            lname: values.lastName,
            dob: moment(values.dob).format("YYYY-MM-DD"),
            address: res?.street_number?.long_name + " " + res.route?.long_name,
            city: res?.locality?.long_name,
            state: res?.administrative_area_level_1?.short_name,
            postalCode: res?.postal_code?.long_name,
          };

          getBranch(searchObject) // searchObject
            .then((res) => {
              dispatch(updateBranchByApiResponse(res.data));
            })
            .catch((error) => {
              console.log(error);
              message.error("Have an error when get branch infomation!");
            });
        })
        .catch((error) => {
          message.error("Have an error when get address infomation!");
          console.log(error);
        });
    },
  });

  const handleDobChanged = (date, dateString) => {
    console.log(dateString);
    if (dateString.length > 0) {
      const utcDate = moment(dateString, dateFormat).utc().toString();
      _formik.setFieldValue("dob", utcDate);
    } else {
      _formik.setFieldValue("dob", "");
    }
  };

  const clearAddress = () => {
    _formik.setFieldValue("currentAddress", "");
  };

  const handleAddressSelect = async (address) => {
    _formik.setFieldValue("currentAddress", address);
    // try {
    //   const results = await geocodeByAddress(address);
    //   console.log(results);
    // } catch (error) {
    //   console.log(error);
    // }
  };

  return (
    <Form className="form-user-info" onFinish={_formik.handleSubmit}>
      <Row gutter={[16, 16]} justify="center">
        <Col xs={24} md={18}>
          <h4 className="title">Contact Info:</h4>

          <Row gutter={[24, 0]}>
            <Image
              className="form-user-info-icon form-user-info-icon-user"
              preview={false}
              src={IconUser.src ?? ""}
              alt=""
            />
            <Col xs={24} md={8}>
              <Form.Item
                validateStatus={_formik.errors.firstName && "error"}
                help={_formik.errors.firstName}
              >
                <Input
                  onChange={_formik.handleChange}
                  onBlur={_formik.handleBlur}
                  name="firstName"
                  value={_formik.values.firstName}
                  errors={_formik.errors.firstName}
                  placeholder="First Name *"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                validateStatus={_formik.errors.lastName && "error"}
                help={_formik.errors.lastName}
              >
                <Input
                  onChange={_formik.handleChange}
                  onBlur={_formik.handleBlur}
                  name="lastName"
                  value={_formik.values.lastName}
                  errors={_formik.errors.lastName}
                  placeholder="Last Name *"
                />
              </Form.Item>
            </Col>

            <Col xs={24} md={8}>
              <Form.Item
                validateStatus={_formik.errors.dob && "error"}
                help={_formik.errors.dob}
              >
                <DatePicker
                  onChange={handleDobChanged}
                  onBlur={(e) => {
                    // console.log("blur", e.target.value)
                    if (
                      moment(e.target.value, dateFormat).isValid() &&
                      e.target.value.length === 10
                    ) {
                      handleDobChanged(null, e.target.value);
                    } else {
                      handleDobChanged(null, "");
                    }
                    _formik.handleBlur(e);
                  }}
                  name="dob"
                  format={dateFormat}
                  value={_formik.values.dob ? moment(_formik.values.dob) : null}
                  errors={_formik.errors.dob}
                  placeholder="Date of birth *"
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={[36, 16]} className="form-user-info-row-address">
            <Image
              className="form-user-info-icon form-user-info-icon-address"
              preview={false}
              src={IconAddress.src ?? ""}
              alt=""
            />
            <Col xs={24}>
              <Form.Item
                validateStatus={_formik.errors.currentAddress && "error"}
                help={_formik.errors.currentAddress}
              >
                <LocationSearchInput
                  formikInstance={_formik}
                  address={_formik.values.currentAddress}
                  clearAddress={clearAddress}
                  onAddressSelect={handleAddressSelect}
                  placeholder="Current Mailing Address"
                  selectWhenChange={true}
                />
              </Form.Item>
              <div className="hint">
                (If you’re purchasing a new home, please put your current
                address, not your new address)
              </div>
            </Col>
          </Row>

          <Row gutter={[16, 16]} className="actions">
            <Col xs={24}>
              <Button
                className="form-submit-button"
                onClick={_formik.handleSubmit}
              >
                Continue
                <Image
                  className="button-icon"
                  preview={false}
                  src={IconArrowRight.src ?? ""}
                  alt=""
                />
              </Button>
            </Col>
          </Row>
        </Col>
      </Row>
    </Form>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;
