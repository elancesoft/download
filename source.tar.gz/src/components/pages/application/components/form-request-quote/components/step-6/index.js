import { Button, Col, Row, Form, Input, message } from "antd";
import { func, shape } from "prop-types";
import { useSelector, useDispatch } from "react-redux";
import LocationSearchInput from "../../../../../../common/location-search-input";
import { useFormik } from "formik";
import { useState } from "react";
import { updateQuote } from "redux/slices/quoteRequestSlice";
import { getBranch } from "actions";
import { getAddressComponent } from "utils";
import { updateBranchByApiResponse } from "redux/slices/branchSlice";
import { updateApiResult } from "redux/slices/apiResultSlice";
import moment from "moment";

function Module({ validationSchema, onStepSubmitted }) {
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const apiResult = useSelector((state) => state?.apiResult ?? {});
  const initialValues = useSelector((state) => ({
    propertyAddress: state?.quoteRequest?.propertyAddress ?? "",
  }));
  const dispatch = useDispatch();

  const [manualMode, setManualMode] = useState(false);

  const { mailingAddressComponent: mailing } = apiResult;

  const _formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => {
      console.log(values.propertyAddress);
      onStepSubmitted(values);

      getAddressComponent(values.propertyAddress)
        .then((res) => {
          dispatch(updateApiResult({ propertyAddressComponent: res }));

          const searchObject = {
            fname: quoteRequest.firstName,
            lname: quoteRequest.lastName,
            dob: moment(quoteRequest.dob).format("YYYY-MM-DD"),
            address: res?.street_number?.long_name + " " + res.route?.long_name,
            city: res?.locality?.long_name,
            state: res?.administrative_area_level_1?.short_name,
            postalCode: res?.postal_code?.long_name,
            mailingAddress: {
              address:
                mailing.street_number.long_name + " " + mailing.route.long_name,
              state: mailing.administrative_area_level_1.short_name,
              city: mailing.locality.long_name,
              postalCode: mailing.postal_code.long_name,
            },
          };

          getBranch(searchObject)
            .then((res) => {
              dispatch(updateBranchByApiResponse(res.data));
              let branchHomeUrl = `https://staff.ourbranch.com/offer/${res?.data?.requestQuote?.id}?option=H`;
              dispatch(
                updateQuote({
                  branchHomePrice: +(res?.data?.homePrice || 0)?.toFixed(2),
                  branchAutoPrice: +(res?.data?.autoPrice || 0)?.toFixed(2),
                  branchHomeUrl,
                })
              );
            })
            .catch((error) => {
              console.log(error);
              message.error("Have an error when get branch infomation!");
            });
        })
        .catch((error) => {
          message.error("Have an error when get property address infomation!");
          console.log(error);
        });
    },
  });

  const clearAddress = () => _formik.setFieldValue("propertyAddress", "");

  const handleAddressSelect = async (address) => {
    await _formik.setFieldValue("propertyAddress", address);
    await _formik.submitForm();
  };

  return (
    <Form className="form-locate-property" onFinish={_formik.handleSubmit}>
      <Row gutter={[16, 24]} align="center">
        <Col xs={24} md={24} lg={17} align="center">
          <h4 className="title">What property do you need coverage for?</h4>
          <br />
          <br />
        </Col>
      </Row>
      <Row gutter={[16, 24]} align="center">
        <Col
          xs={24}
          md={24}
          lg={17}
          align="center"
          id="form_locate_property_input_address"
        >
          <Form.Item
            validateStatus={_formik.errors.propertyAddress && "error"}
            help={_formik.errors.propertyAddress}
          >
            {manualMode ? (
              <Input
                onChange={_formik.handleChange}
                onBlur={_formik.handleBlur}
                name="propertyAddress"
                value={_formik.values.propertyAddress}
                errors={_formik.errors.propertyAddress}
                placeholder="Address"
              />
            ) : (
              <LocationSearchInput
                formikInstance={_formik}
                address={_formik.values.propertyAddress}
                clearAddress={clearAddress}
                onAddressSelect={handleAddressSelect}
                placeholder="Address"
              />
            )}
          </Form.Item>
        </Col>
      </Row>

      <Row gutter={[16, 12]} align="center">
        <Col xs={24} md={24} lg={17} align="left">
          <Button
            className="mode-toggler"
            type="link"
            onClick={() => setManualMode(!manualMode)}
          >
            {manualMode ? "google address" : "Manually enter address"}
          </Button>
        </Col>
        {manualMode && (
          <Col xs={24} md={24} lg={17} align="left">
            <Button
              className="button-primary-one"
              onClick={_formik.handleSubmit}
            >
              Continue
            </Button>
          </Col>
        )}
      </Row>
    </Form>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;
