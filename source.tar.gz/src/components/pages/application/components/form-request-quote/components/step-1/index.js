/* eslint-disable react/prop-types */
import { Col, Form, Image, Row } from "antd";
import { useFormik } from "formik";
import { useSelector } from "react-redux";
import { func, shape } from "prop-types";
import { getImage } from "../../../../../../../utils/string";

import ModuleInsuranceTypes from "../../../../../../common/insurance-types";
import IconHome from "../../../../../../../../public/images/pages/application/application_form_icon_home.svg";
import IconCar from "../../../../../../../../public/images/pages/application/application_form_icon_car.svg";
import DefaultImage from "../../../../../../../../public/images/pages/application/application_form_image_default_1.svg";

const insuranceTypes = [
  {
    label: "Home",
    value: "Home",
    icons: [IconHome],
  },
  {
    label: "Auto",
    value: "Auto",
    icons: [IconCar],
  },
  {
    label: "Bundle",
    value: "Bundle",
    icons: [IconHome, IconCar],
  },
];

function Module({ validationSchema, onStepSubmitted }) {
  const initialValues = useSelector((state) => ({
    insuranceType: state?.quoteRequest?.insuranceType ?? "",
  }));
  const user = useSelector((state) => state.user);

  const _formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: (values) => onStepSubmitted(values),
  });

  const handleInsuranceTypeSelected = async (insuranceType) => {
    await _formik.setFieldValue("insuranceType", insuranceType);
    _formik.handleSubmit();
  };

  return (
    <Form className="form-insurance-type" onFinish={_formik.handleSubmit}>
      <Row
        gutter={[
          { xs: 0, md: 256 },
          { xs: 36, md: 48 },
        ]}
      >
        <Col className="text" xs={24} lg={11}>
          <h5 className="text-head">Welcome!</h5>
          <p className="text-body">
            First, tell us what kind of insurance you would like a quote for!
          </p>
          <p className="text-foot">
            <img src="/images/pages/application/time.svg" alt="" />
            <span>3-4 minutes to complete</span>
          </p>
          <ModuleInsuranceTypes
            current={_formik.values.insuranceType}
            insuranceTypes={insuranceTypes}
            onSelected={handleInsuranceTypeSelected}
          />
          {!_formik.isValid && (
            <p className="message error">Insurance type is invalid!</p>
          )}
        </Col>
        <Col className="image" xs={24} lg={13} align="center">
          <Image
            preview={false}
            src={getImage(user?.introimage) || DefaultImage.src}
            alt=""
          />
        </Col>
      </Row>
    </Form>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;
