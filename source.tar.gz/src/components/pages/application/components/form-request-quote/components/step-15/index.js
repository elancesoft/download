import { Row, Col, Upload, Button, Input, Checkbox, message } from "antd";
import { MailOutlined, ArrowRightOutlined } from "@ant-design/icons";
import { useSelector } from "react-redux";
import { useState, useEffect, Fragment } from "react";
import { func, shape } from "prop-types";
import { getFlood, getNationwide, sendMailAccurateQuote, sendMailLineOfBusiness } from '../../../../../../../actions';
import moment from 'moment';

const packages = [
  {
    icon: "/images/pages/application/flood_1.jpg",
    name: "Flood Dertimination",
    status: "Returned",
    risk: "A - High Risk",
  },
  {
    icon: "/images/pages/application/flood_3.jpg",
    name: "Insurance Quotes",
    status: "Ordered - Pending",
    risk: "Pending",
  },
  {
    icon: "/images/pages/application/flood_2.jpg",
    name: "Insurance Report",
    status: "Ordered - Pending",
    risk: "Pending",
  },
];

const provideAdditional = [
  {
    image: "/images/pages/application/add_1.PNG",
    text: "Jewely",
  },
  {
    image: "/images/pages/application/add_2.PNG",
    text: "Umbrella",
  },
  {
    image: "/images/pages/application/add_3.PNG",
    text: "Life",
  },
  {
    image: "/images/pages/application/add_4.PNG",
    text: "Business",
  },
  {
    image: "/images/pages/application/add_5.PNG",
    text: "Other",
  },
];

function Module({ onStepSubmitted }) {
  const user = useSelector((state) => state?.user ?? {});
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const { floodZone } = useSelector((state) => state?.apiResult ?? {});
  const { emails, householdCars, householdMembers } = quoteRequest;
  const [cars, setCars] = useState(
    householdCars.map((item) => ({ ...item, VIN: item.VIN || "" }))
  );
  const [persons, setPersons] = useState(
    householdMembers.map((item) => ({ ...item }))
  );
  const [additionalQuoteSelected, setAdditionalQuoteSelected] = useState([]);

  packages[0].risk = floodZone || "Pending";

  const handleChangeCarVIN = (index, value) => {
    setCars((cars) =>
      cars.map((car, i) => {
        if (i == index) {
          car.VIN = value;
        }
        return car;
      })
    );
  };

  const handleChangPersonLicence = (index, value) => {
    setPersons((persons) =>
      persons.map((person, i) => {
        if (i == index) {
          person.license = value;
        }
        return person;
      })
    );
  };

  const handleToggleAdditionalQuoteSelected = (name) => {
    console.log(additionalQuoteSelected);
    if (additionalQuoteSelected.includes(name)) {
      setAdditionalQuoteSelected((value) =>
        value.filter((item) => item !== name)
      );
    } else {
      setAdditionalQuoteSelected((value) => [...value, name]);
    }
  };

  const handleSubmitProvideVinCars = () => {
    const data = {
      ...quoteRequest,
      householdMembers: persons,
      householdCars: cars,
      user,
    };
    console.log(data)
    sendMailAccurateQuote(data)
      .then(res=> {
        message.success('Quote submitted successfully !!');
      })
      .catch(error => {
        console.log(error)
        message.error('Have an error when submit your form!');
      });
  }
  const handleSendMailLineOfBusinesse = () => {
    const data = {
      ...quoteRequest,
      user,
      items: additionalQuoteSelected,
    };
    sendMailLineOfBusiness(data)
      .then(res=> {
        message.success('Quote submitted successfully !!');
      })
      .catch(error => {
        console.log(error)
        message.error('Have an error when submit your form!');
      });
  }

  return (
    <section className="step-page-15">
      <div>
        <Row gutter={[16, 24]} className="head-wrapper" align="center">
          <Col xs={24} md={8}>
            <p className="subheading">Application Status:</p>
            <h2 className="heading">Complete</h2>
          </Col>
          <Col xs={24} md={16} className="email-note">
            <MailOutlined />
            <p>
              We're working on your quote! We'll email <span>{emails[0]}</span>
              {emails?.[1] && " and "}
              {emails?.[1] && <span>{emails?.[1]}</span>} when we are finished!
            </p>
          </Col>
        </Row>
      </div>
      <div className="package-wrapper">
        <h3 className="title">Your package</h3>
        <Row className="package-list" gutter={[12, 12]}>
          {packages.map((item, i) => (
            <Fragment key={i}>
              <Col xs={4}>
                <img src={item.icon} alt="" width="36"/>
              </Col>
              <Col xs={12}>
                <p>{item.name}</p>
                <span className={`${item.status === "Returned" && "green"}`}>
                  {item.status}
                </span>
              </Col>
              <Col xs={8}>{item.risk}</Col>
            </Fragment>
          ))}
        </Row>
      </div>
      <div>
        <h3 className="title">Can you provide some additional info?</h3>
        <Row gutter={24} className="additional-info">
          <Col xs={24} md={12}>
            <Row gutter={[12, 12]} align="middle">
              {cars.map((item, i) => (
                <Fragment key={i}>
                  <Col xs={3} md={2}>
                    <img src="/images/pages/application/warning.svg" />
                  </Col>
                  <Col xs={3}  md={2}>
                    <img src="/images/pages/application/car_info.PNG" />
                  </Col>
                  <Col xs={15}  md={18}>
                    <Input
                      value={item.VIN}
                      onChange={(e) => handleChangeCarVIN(i, e.target.value)}
                      placeholder={item.model + " VIN"}
                    />
                  </Col>
                  <Col xs={3} md={2}>
                    {item.VIN.length > 0 ? (
                      <img src="/images/pages/application/circle_check.svg" />
                    ) : (
                      <img src="/images/pages/application/circle_uncheck.svg" />
                    )}
                  </Col>
                </Fragment>
              ))}
              {persons.map((item, i) => (
                <Fragment key={i}>
                  <Col xs={3} md={2}>
                    <img src="/images/pages/application/warning.svg" />
                  </Col>
                  <Col xs={3} md={2}>
                    <img src="/images/pages/application/profile_info.PNG" />
                  </Col>
                  <Col xs={15} md={18}>
                    <Input
                      value={item.license}
                      onChange={(e) =>
                        handleChangPersonLicence(i, e.target.value)
                      }
                      placeholder={item.firstName + " " + item.lastName + " license"}
                    />
                  </Col>
                  <Col xs={3} md={2}>
                    {item.license.length > 0 ? (
                      <img src="/images/pages/application/circle_check.svg" />
                    ) : (
                      <img src="/images/pages/application/circle_uncheck.svg" />
                    )}
                  </Col>
                </Fragment>
              ))}
            </Row>
          </Col>
          <Col>
            <Button className="form-submit-button" onClick={handleSubmitProvideVinCars} >
              Send
              <img
                src="/images/pages/application/application_form_icon_arrow_right.svg"
                alt=""
              />
            </Button>
          </Col>
        </Row>
      </div>
      <div className="additional-lines">
        <h3 className="title">
          Tap any additional lines we can provide quote for.
        </h3>
        <Row className="additional-list" gutter={[12, 12]}>
          {provideAdditional.map((item, i) => (
            <Col xs={12} md={8} lg={4}>
              <div
                className={`additional-item ${
                  additionalQuoteSelected.includes(item.text) ? "active" : ""
                }`}
                onClick={() => handleToggleAdditionalQuoteSelected(item.text)}
              >
                <p>{item.text}</p>
                <img src={item.image} />
              </div>
            </Col>
          ))}
        </Row>
        <Button className="form-submit-button" onClick={handleSendMailLineOfBusinesse}>
          Send
          <img
            src="/images/pages/application/application_form_icon_arrow_right.svg"
            alt=""
          />
        </Button>
      </div>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
