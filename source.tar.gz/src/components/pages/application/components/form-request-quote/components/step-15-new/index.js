import {
  Row, Col, Upload, Button, Input, message,
} from 'antd';
import { useEffect, useRef, useState } from 'react';
import { useSelector } from 'react-redux';
import { func } from 'prop-types';

import IconHippo from '../../../../../../../../public/images/pages/application/application_form_icon_hippo.svg';
import IconStillWater
  from '../../../../../../../../public/images/pages/application/application_form_icon_still_water.svg';
import IconNeptune from '../../../../../../../../public/images/pages/application/application_form_icon_neptune.svg';
import IconCarInfo from '../../../../../../../../public/images/pages/application/car_info.PNG';
import IconWarning from '../../../../../../../../public/images/pages/application/warning.svg';
import IconChecked from '../../../../../../../../public/images/pages/application/circle_check.svg';
import IconUnChecked from '../../../../../../../../public/images/pages/application/circle_uncheck.svg';
import IconComplete from '../../../../../../../../public/images/pages/application/application_form_icon_complete.svg';
import IconDrivingLicense from '../../../../../../../../public/images/pages/application/profile_info.svg';
import IconSendMail from '../../../../../../../../public/images/pages/application/application_form_send_mail_icon.svg';
import IconUser from '../../../../../../../../public/images/pages/application/application_form_icon_user.svg';
import IconMessage from '../../../../../../../../public/images/pages/application/application_form_icon_message.svg';
import { DeleteOutlined, FileOutlined } from '@ant-design/icons';
import { convertToSortSize } from '../../../../../../../utils';
import { getFlood, getNationwide, submitFormApply, sendMailAccurateQuote, sendMailLineOfBusiness } from '../../../../../../../actions';
import moment from 'moment';

const moreQuotesItems = [
  {
    image: '/images/pages/application/add_1.PNG',
    text: 'Jewely',
  },
  {
    image: '/images/pages/application/add_2.PNG',
    text: 'Umbrella',
  },
  {
    image: '/images/pages/application/add_3.PNG',
    text: 'Life',
  },
  {
    image: '/images/pages/application/add_4.PNG',
    text: 'Business',
  },
  {
    image: '/images/pages/application/add_5.PNG',
    text: 'Other',
  },
];

const previewItems = [
  {
    image: IconHippo.src,
    type: 'Home',
    price: '$1,003 / year',
  },
  {
    image: IconStillWater.src,
    type: 'Home',
    price: '$1,003 / year',
  },
  {
    image: IconNeptune.src,
    type: 'Flood',
    price: '$1,003 / year',
  },
];

const quotesItemStatus = [
  {
    name: '1. Household Information',
    finished: true,
  },
  {
    name: '2. Risk Tolerance',
    finished: true,
  },
  {
    name: '3. Home Risk Profile',
    finished: true,
  },
  {
    name: '4. Current Insurance Information',
    finished: true,
  },

  {
    name: '5. Auto Insurance Risk Profile',
    finished: true,
  },
  {
    name: '6. User Notes',
    finished: true,
  },
];

const floodStatus = {
  flood_zone: 'X',
};

function Module({ onStepSubmitted }) {
  const quoteRequest = useSelector(
    (store) => store.quoteRequest,
  );
  const {
    householdCars = [], householdMembers = [], emails = [], propertyAddress = '', uploadedDocuments = [],
  } = quoteRequest;
  const user = useSelector((state) => state?.user ?? {});

  // Filter null car and member null
  const [cars, setCars] = useState(householdCars.filter((car) => car.model && car.type && car.year));
  const [members, setMembers] = useState(householdMembers.filter((member) => member.firstName && member.lastName && member.license?.length <= 0));
  const isCarsAndMembersValid = useRef(members.every((member) => member.license?.length > 0) && cars.every((car) => car.VIN?.length > 0));
  const [otherQuotes, setOtherQuotes] = useState(moreQuotesItems);
  const [uploadDocuments, setUploadDocuments] = useState(uploadedDocuments.map((document) => ({ ...document })));
  const [isSubmittingForm, setIsSubmittingForm] = useState(false);
  const [isFormSubmissionSuccess, setIsFormSubmissionSuccess] = useState(false);
  const [floodZone, setFloodZone] = useState('');

  const handleCarVINChanged = (index, value) => {
    const clonedCars = cars.map((car) => ({ ...car }));
    clonedCars[index].VIN = value;
    setCars(clonedCars);
  };

  const handleMemberLicenseChanged = (index, value) => {
    const clonedMembers = members.map((member) => ({ ...member }));
    clonedMembers[index].license = value;
    setMembers(clonedMembers);
  };

  const handleFileListChanged = ({ fileList }) => {
    if (fileList.length > 4) {
      message.error('Do not upload more than 4 photos');
      return;
    }
    setUploadDocuments(fileList);
  };

  const fileItemRender = (originNode, file, fileList, actions) => (
    <div className="file-preview">
      <div className="icon">
        <FileOutlined />
        <span className="ext">{file.name.replace(/(.+\.)/g, '')}</span>
      </div>
      <div className="content">
        <p className="name">{file.name}</p>
        <div className="process" />
        <p className="size">{convertToSortSize(file.size)}</p>
        <span />
      </div>
      <div className="action">
        <DeleteOutlined onClick={actions.remove} />
      </div>
    </div>
  );

  // const submitAdditionalInfos = async () => {
  //   await setIsSavingAdditionalInfos(true);
  //
  //   setTimeout(async () => {
  //     await setIsSavingAdditionalInfos(false);
  //     message.success('Successfully save additional information!');
  //   }, 1000);
  // };

  const submitForm = async () => {
    setIsSubmittingForm(true);
    const parsedOtherQuotes = otherQuotes.filter((quote) => quote.isActive).map((quote) => quote.text);

    const data = {
      ...quoteRequest,
      householdMembers: members,
      householdCars: cars,
      user,
      note: user?.note ?? '',
      items: parsedOtherQuotes ?? [],
    };
    delete data.uploadedDocuments;

    const formData = new FormData();
    formData.append('data', JSON.stringify(data));
    //
    // console.log({
    //   ...quoteRequest,
    //   householdMembers: members,
    //   householdCars: cars,
    //   user,
    //   note: user?.note ?? '',
    //   items: parsedOtherQuotes ?? [],
    // });

    uploadedDocuments.forEach((document) => {
      formData.append('files[]', document);
    });

    try {
      await submitFormApply(formData);
      setIsFormSubmissionSuccess(true);
      message.success('Quote submitted successfully !!');
    } catch (error) {
      message.error('Have an error when submit your form!');
      console.log(error);
    }
    setIsSubmittingForm(false);
  };

  const handleSubmitProvideLisenceAndVin = () => {
    const data = {
      ...quoteRequest,
      householdMembers: members,
      householdCars: cars,
      user,
    };
    sendMailAccurateQuote(data)
      .then(res=> {
        message.success('Quote submitted successfully !!');
      })
      .catch(error => {
        console.log(error)
        message.error('Have an error when submit your form!');
      });
  }

  const handleSendMailLineOfBusinesse = () => {
    const parsedOtherQuotes = otherQuotes.filter((quote) => quote.isActive).map((quote) => quote.text);

    const data = {
      ...quoteRequest,
      user,
      items: parsedOtherQuotes ?? [],
    };
    sendMailLineOfBusiness(data)
      .then(res=> {
        message.success('Quote submitted successfully !!');
      })
      .catch(error => { 
        console.log(error)
        message.error('Have an error when submit your form!');
      });
  }

  const activateQuote = (index) => {
    const clonedQuotes = otherQuotes.map((quote) => ({ ...quote }));
    clonedQuotes[index].isActive = !clonedQuotes[index]?.isActive ?? false;
    setOtherQuotes(clonedQuotes);
  };

  useEffect(() => {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode(
      {
        address: propertyAddress,
      },
      (results) => {
        const mapSettings = {
          zoom: 12,
          center: {
            lat: results?.[0]?.geometry?.location?.lat(),
            lng: results?.[0]?.geometry?.location?.lng(),
          },
          disableDefaultUI: true,
          scaleControl: false,
          draggable: false,
        };
        const map = new google.maps.Map(document.getElementById('map_canvas'), mapSettings);

        if (results.length > 0) {
          const searchObjectNationwide = {
            email: quoteRequest.emails[0],
            firstName: quoteRequest.firstName,
            lastName: quoteRequest.lastName,
            dob: moment(quoteRequest.dob).format('YYYY-MM-DD'),
            street: quoteRequest.currentAddress,
            square: quoteRequest.house.squareFeet,
            yearBuilt: quoteRequest.house.yearBuilt,
          };
          const searchObjectFlood = {
            address: quoteRequest.propertyAddress,
            square: quoteRequest.house.squareFeet,
            yearBuilt: quoteRequest.house.yearBuilt,
          };
          const addressComponents = results?.[0]?.address_components || [];
          for (const address of addressComponents) {
            if (address.types.includes('administrative_area_level_1')) {
              searchObjectNationwide.state = address.short_name;
              searchObjectFlood.state = address.short_name;
            }
            if (address.types.includes('locality')) {
              searchObjectNationwide.city = address.long_name;
              searchObjectFlood.city = address.long_name;
            }
            if (address.types.includes('postal_code')) {
              searchObjectNationwide.postalCode = address.long_name;
              searchObjectFlood.zip = address.long_name;
            }
          }
          try {
            getNationwide(searchObjectNationwide);
            getFlood(searchObjectFlood).then((res) => {
              console.log(res);
              setFloodZone(res?.data?.square?.flood_zone ?? '');
            });
          } catch (error) {
            console.log(error);
          }
        }
      },
    );
  }, []);

  return (
    <section className="step-page-16">

      {/* Title & Description */}
      <div className="title">
        Application Complete!
        <img className="icon" src={IconComplete.src} alt=""/>
      </div>

      <div className="description">
        <img className="icon" src={IconSendMail.src} alt=""/>
        <div className="content">
          We are working on your quote. We’ll email it to
          {' '}
          <strong>{emails[0]}</strong>
          {
            emails[1] && (
              <>
                {' '}
                and
                {' '}
                <strong>{`  ${emails[1]} `}</strong>
              </>
            )
          }
          {' '}
          as soon as we are done!
        </div>
      </div>

      <Row className='main'>
        <Col>
          {/* Form Cars & Licenses */}
          <div className="grid-item form-more-information">
            <div className="title">
              Can you provide us this information?
            </div>
            {
              isCarsAndMembersValid.current === true ? (
                <div className="content">
                  All cars and members is valid
                </div>
              ) : (
                <div className="list">
                  {
                    cars.map((car, index) => (
                      <div className="item">
                        <img className="icon" src={IconWarning.src} alt=""/>
                        <img className="icon" src={IconCarInfo.src} alt=""/>
                        <Input
                          placeholder={`${car.model} VIN`}
                          onChange={(e) => handleCarVINChanged(index, e.target.value)}
                          value={car.VIN ?? ''}
                          disabled={isSubmittingForm}
                        />
                        {
                          car?.VIN?.length > 0 ? (
                            <img className="icon" src={IconChecked.src} alt=""/>
                          ) : (
                            <img className="icon" src={IconUnChecked.src} alt=""/>
                          )
                        }
                      </div>
                    ))
                  }
                  {
                    members.map((member, index) => (
                      <div className="item">
                        <img className="icon" src={IconWarning.src} alt=""/>
                        <img className="icon" src={IconDrivingLicense.src} alt=""/>
                        <Input
                          placeholder={`${`${member.firstName} ${member.lastName}`} driving license`}
                          onChange={(e) => handleMemberLicenseChanged(index, e.target.value)}
                          value={member.license ?? ''}
                          disabled={isSubmittingForm}
                        />
                        {
                          member?.license?.length > 0 ? (
                            <img className="icon" src={IconChecked.src} alt=""/>
                          ) : (
                            <img className="icon" src={IconUnChecked.src} alt=""/>
                          )
                        }
                      </div>
                    ))
                  }
                </div>
              )
            }
            <Button
              className="button-submit"
              onClick={handleSubmitProvideLisenceAndVin}
              loading={isSubmittingForm}
            >
              Submit
            </Button>
          </div>
          {/* Review Quotes Requests */}
          <div className="grid-item quote-request-review">
            <div className="description">
              We are now working on your proposal and will be in touch shortly. If you have an extra minute,check out some
              of the information below.
            </div>

            <div className="list">
              {
                quotesItemStatus.map((item) => (
                  <div className="item">
                    <div className="header">
                      {item.name}
                      {
                        item?.finished ? (
                          <img className="icon" src={IconChecked.src} alt=""/>
                        ) : (
                          <img className="icon" src={IconUnChecked.src} alt=""/>
                        )
                      }
                    </div>
                  </div>
                ))
              }

              <div className="item">
                <div className="header">
                  7. Uploads
                  {
                    uploadDocuments?.length > 0 ? (
                      <img className="icon" src={IconChecked.src} alt=""/>
                    ) : (
                      <img className="icon" src={IconUnChecked.src} alt=""/>
                    )
                  }
                </div>

                <div className="content">
                  <Upload
                    multiple
                    onChange={handleFileListChanged}
                    fileList={uploadDocuments}
                    beforeUpload={() => false}
                    itemRender={fileItemRender}
                  >
                    <Button id="upload_file_button" className="button-submit-two">Upload&nbsp;&nbsp;+</Button>
                  </Upload>
                </div>
              </div>

              <div className="item">
                <div className="header">
                  8. Other Info
                  {
                    isFormSubmissionSuccess === true ? (
                      <img className="icon" src={IconChecked.src} alt=""/>
                    ) : (
                      <img className="icon" src={IconUnChecked.src} alt=""/>
                    )
                  }
                </div>
                {
                  isCarsAndMembersValid.current === true ? (
                    <div className="content">
                      All cars and members is valid
                    </div>
                  ) : (
                    <div className="content">
                      <div className="form-other-info">
                        {
                          cars.map((car, index) => (
                            <div className="item">
                              <img className="icon" src={IconCarInfo.src} alt=""/>
                              <Input
                                placeholder={`${car.model} VIN`}
                                onChange={(e) => handleCarVINChanged(index, e.target.value)}
                                value={car.VIN ?? ''}
                                disabled={isSubmittingForm}
                              />
                            </div>
                          ))
                        }
                        {
                          members.map((member, index) => (
                            <div className="item">
                              <img className="icon" src={IconDrivingLicense.src} alt=""/>
                              <Input
                                placeholder={`${member.firstName + member.lastName} driving license`}
                                onChange={(e) => handleMemberLicenseChanged(index, e.target.value)}
                                value={member.license ?? ''}
                                disabled={isSubmittingForm}
                              />
                            </div>
                          ))
                        }
                        <Button
                          className="button-submit-two"
                          loading={isSubmittingForm}
                          onClick={handleSubmitProvideLisenceAndVin}
                        >
                          Submit
                        </Button>
                      </div>
                    </div>
                  )
                }
              </div>

              <div className="item more-quotes">
                <div className="header">
                  9. Need More Quotes?
                  {
                    otherQuotes.filter((quote) => quote.isActive)?.length > 0 ? (
                      <img className="icon" src={IconChecked.src} alt=""/>
                    ) : (
                      <img className="icon" src={IconUnChecked.src} alt=""/>
                    )
                  }
                </div>

                <div className="content">
                  <div className="list">
                    {
                      otherQuotes.map((item, index) => (
                        <a
                          className={`item ${item?.isActive ? 'active' : ''}`}
                          onClick={() => activateQuote(index)}
                        >
                          <div className="text">
                            {item.text}
                          </div>
                          <img src={item.image} alt=""/>
                        </a>
                      ))
                    }
                  </div>
                  <Button
                    className="button-submit"
                    loading={isSubmittingForm}
                    onClick={handleSendMailLineOfBusinesse}
                  >
                    Submit
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Col>
        <Col>
          {/* Show Flood Zone */}
          <div className="grid-item flood-zone">
            <div className="title">
              Flood Zone
            </div>
            <div className="map-wrapper">
              <div className="flood-content">
                {
                  `${floodZone}`
                }
              </div>
              <div id="map_canvas">
                map
              </div>
            </div>
          </div>
          {/* Preview Price */}
          <div className="grid-item preview-prices">
            <div className="title">
              Preview Prices:
            </div>
            <div className="description">
              Your best prices are likely to come from your agent but here are a few instant quotes. We were able to
              provide you.
            </div>
            <div className="list">
              {
                previewItems.map((item) => (
                  <div className="item">
                    <img src={item.image} alt=""/>
                    <div className="name">
                      {item.type}
                    </div>
                    <div className="price">
                      {item.price}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
          {/* Show Applicant Information */}
          <div className="grid-item applicant">
            <div className="title">Your Agent:</div>
            <div className="content">
              <div className="description">
                <img className="icon" src={IconMessage.src} alt=""/>
                Have a question? Give your agent an email or
                call to connect at any time!
              </div>

              <div className="applicant-content">
                <img className="icon" src={IconUser.src} alt=""/>
                <div className="name">
                  { `${user.firstname} ${user.lastname}` ?? ''}
                </div>

                <div className="headline">
                  {user.agencyname ?? ''}
                </div>

                <div className="phone">
                  {user.phone || ''}
                </div>

                <div className="email">
                  {user.email || ''}
                </div>
              </div>

              <div className="agent-image">
                <img src="http://18.232.91.105/about_us_sec_6_img_9.png" alt=""/>
              </div>
            </div>
          </div>
        </Col>
      </Row>

      <div className="main">
        

        
      </div>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
