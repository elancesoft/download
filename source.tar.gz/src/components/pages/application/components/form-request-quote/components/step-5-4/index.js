import { Image, Button, Col, Row } from "antd";
import { func } from "prop-types";
import IconQuantify from "../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import { useSelector } from "react-redux";

const options = ["Yes", "No"];

function Module({ onStepSubmitted }) {
  const riskSelectedOption = useSelector(
    (state) => state?.quoteRequest?.riskOption3 ?? ""
  );

  const pickOption = (value) => {
    onStepSubmitted({
      riskOption3: value,
    });
  };

  return (
    <Row gutter={[16, 24]} align="center" className="form-risk-score one">
      {/* <Col xs={24} align="right">
        <Button
          className="form-submit-button skip-button"
          onClick={() => pickOption("")}
        >
          Skip
          <Image
            className="button-icon"
            preview={false}
            src={IconArrowRight.src ?? ""}
            alt=""
          />
        </Button>
      </Col> */}
      <Col xs={24} md={24} lg={14} align="center">
        <Image
          rootClassName="form-quantified-risk-icon"
          preview={false}
          src={IconQuantify.src ?? ""}
          alt=""
        />
        {/* <h4 className="title">
          Would you pay $75 each year to avoid a 5% chance of losing 5,000?
        </h4> */}
        <h4 className="text-[30px] text-center font-semibold leading-tight">
          Would you pay $200 per year to cover you for a 1 in 50 claim event?
        </h4>
        <div className="text-[14px] text-[#00b4ff] my-[16px]">3 of 5</div>
        <div className="w-full space-y-4">
          {options.map((option, i) => (
            <div
              className={`max-w-[300px] h-16 leading-[4rem] border border-solid border-black rounded-lg mx-auto transition-colors hover:bg-black hover:text-white cursor-pointer ${
                riskSelectedOption === option ? "bg-black text-white" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              {option}
            </div>
          ))}
        </div>
        <img className="mx-auto mt-[40px]" src="/images/icons/storm-eye.svg" />
        <div className="max-w-[400px] grid grid-cols-10 gap-1 mt-[80px] mb-[40px]">
          {[...new Array(50)].map((item, i) => (
            <img
              className="w-full p-[2px]"
              src={`/images/icons/home-${i === 36 ? "red" : "gray"}.svg`}
            />
          ))}
        </div>
        {/* <div className="options">
          {options.map((option) => (
            <Button
              className={`form-submit-button style-one ${
                riskSelectedOption === option ? "selected" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              {option}
            </Button>
          ))}
        </div> */}
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
