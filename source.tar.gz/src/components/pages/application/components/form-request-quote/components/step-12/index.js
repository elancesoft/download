/* eslint-disable react/prop-types,no-underscore-dangle */
import { FieldArray, Formik, Field } from "formik";
import {
  Form,
  Col,
  Row,
  Button,
  Image,
  Input,
  Select,
  Spin,
  message,
} from "antd";
import { CloseOutlined } from "@ant-design/icons";
import { useSelector, useDispatch } from "react-redux";
import { func, shape } from "prop-types";

import IconCar2 from "../../../../../../../../public/images/pages/application/application_form_icon_car_2.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";

import { useState, useEffect } from "react";
import { updateQuote } from "../../../../../../../redux/slices/quoteRequestSlice";
import { updateApiResult } from "../../../../../../../redux/slices/apiResultSlice";
import { toggleOffCar } from "../../../../../../../redux/slices/branchSlice";
import {
  getNationwideAuto,
  getTravelerAuto,
  getAAAAuto,
} from "../../../../../../../actions";
import moment from "moment";
import { getAddressComponent } from "../../../../../../../utils";
import { getImage } from "../../../../../../../utils/string";
import useRequestBody from "hooks/useRequestBody";

const { Option } = Select;

const defaultImage =
  "/images/pages/application/application_form_image_default_1.svg";

const renderYearOptions = (start, end) => {
  const options = [];
  for (let i = end; i >= start; i -= 1) {
    options.push(
      <Option key={i} value={i}>
        {i}
      </Option>
    );
  }
  return options;
};

function Module({ onStepSubmitted }) {
  const quoteRequest = useSelector((state) => state?.quoteRequest);
  const user = useSelector((store) => store.user);
  const apiResult = useSelector((state) => state?.apiResult ?? {});
  const householdCars = useSelector(
    (state) => state?.quoteRequest?.householdCars ?? []
  );
  const dispatch = useDispatch();
  const { nationwideAutoBody, travelerAutoBody, aaaAutoBody } =
    useRequestBody();

  const handleFormSubmitted = (values) => {
    if (values.householdCars.length > 6) {
      message.error("You can not submit more than 6 cars");
    } else {
      let cars = values.householdCars.filter(
        (item) => item.year && item.make && item.model
      );

      onStepSubmitted({ householdCars: cars });

      console.log(cars, cars?.length > 0);
      if (user?.isEnableApi && cars?.length > 0) {
        getPriceApi(cars);
      }
    }
  };

  const getPriceApi = (cars) => {
    if (user?.nationwide_api?.isOn) {
      getNationwideAuto(nationwideAutoBody({ cars }))
        .then((res) => {
          console.log("nationwide_auto", res.data);
          let nationwideAutoPrice = +res.data?.autoPrice || 0;
          dispatch(updateQuote({ nationwideAutoPrice }));
        })
        .catch((error) => {
          dispatch(updateQuote({ nationwideAutoPrice: 0 }));
          console.log("nationwide_auto error", error);
        });
    }

    if (user?.traveler_api?.isOn) {
      getTravelerAuto(travelerAutoBody({ cars }))
        .then((res) => {
          console.log("traveler_auto", res.data);
          let travelerAutoPrice =
            +res.data?.autoPrice ||
            +res.data?.result.IntegratedPartnerAutoQuoteResponse
              ?.IntegratedPartnerAutoQuoteOutput?.[0]?.Output?.[0]?.ACORD?.[0]
              ?.InsuranceSvcRs?.[0]?.PersAutoPolicyQuoteInqRs?.[0]
              ?.PolicySummaryInfo?.[0]?.FullTermAmt?.[0]?.Amt?.[0] ||
            0;
          dispatch(updateQuote({ travelerAutoPrice }));
        })
        .catch((error) => {
          dispatch(updateQuote({ travelerAutoPrice: 0 }));
          console.log("traveler_auto error", error);
        });
    }

    if (user?.aaa_api?.isOn) {
      getAAAAuto(aaaAutoBody({ cars }))
        .then((res) => {
          console.log("aaa_auto", res.data);
          let aaaAutoPrice = +res.data?.autoPrice || 0;
          dispatch(updateQuote({ aaaAutoPrice }));
        })
        .catch((error) => {
          dispatch(updateQuote({ aaaAutoPrice: 0 }));
          console.log("aaa_auto error", error);
        });
    }
  };

  return (
    <div className="form-step-12">
      <Row gutter={[16, 16]}>
        <Col xs={24} md={24} lg={17} xl={16}>
          <div className="text">
            <h4 className="title">What cars are in your household?</h4>
            <div className="description">
              Bundling car and home insurance can save up to 35%. It’s always
              good to check this scout when shopping.
            </div>
          </div>

          <Formik
            initialValues={{
              householdCars: [
                ...householdCars.map((item) => ({
                  year: item.year ?? undefined,
                  make: item.make ?? undefined,
                  model: item.model ?? undefined,
                  costNew: item.costNew ?? undefined,
                  VIN: item.VIN ?? undefined,
                })),
                // Add a blank item instead for user to fill when detect no car
                ...(householdCars?.length <= 0
                  ? [
                      {
                        year: undefined,
                        make: undefined,
                        model: undefined,
                        costNew: undefined,
                        VIN: undefined,
                      },
                    ]
                  : []),
              ],
            }}
            onSubmit={handleFormSubmitted}
            render={({
              values,
              errors,
              handleChange,
              handleBlur,
              setFieldValue,
              handleSubmit,
            }) => (
              <Form>
                <FieldArray
                  name="householdCars"
                  render={(arrayHelpers) => (
                    <>
                      {values?.householdCars?.length > 0 &&
                        values?.householdCars?.map((householdCar, index) => (
                          // eslint-disable-next-line react/no-array-index-key
                          <div key={index} className="flex space-x-4 text-left">
                            <Image
                              rootClassName="icon w-24"
                              preview={false}
                              src={IconCar2.src}
                              alt=""
                            />

                            <Form.Item
                              className="select-year w-40"
                              validateStatus={
                                errors?.householdCars?.[index]?.year && "error"
                              }
                              help={errors?.householdCars?.[index]?.year ?? ""}
                            >
                              <Select
                                name={`householdCars.${index}.year`}
                                placeholder="Year"
                                value={values?.householdCars?.[index]?.year}
                                onChange={(value) =>
                                  setFieldValue(
                                    `householdCars.${index}.year`,
                                    value
                                  )
                                }
                                suffixIcon={null}
                              >
                                {renderYearOptions(
                                  1922,
                                  new Date().getFullYear() + 1
                                )}
                              </Select>
                            </Form.Item>

                            <Form.Item
                              className="select-make w-72"
                              validateStatus={
                                errors?.householdCars?.[index]?.make && "error"
                              }
                              help={errors?.householdCars?.[index]?.make}
                            >
                              <Select
                                name={`householdCars.${index}.make`}
                                placeholder="Make"
                                value={values?.householdCars?.[index]?.make}
                                onChange={(value) =>
                                  setFieldValue(
                                    `householdCars.${index}.make`,
                                    value
                                  )
                                }
                                suffixIcon={null}
                              >
                                {carMakers.map((carMaker) => (
                                  <Option
                                    key={carMaker}
                                    value={carMaker.toUpperCase()}
                                  >
                                    {carMaker.toUpperCase()}
                                  </Option>
                                ))}
                              </Select>
                            </Form.Item>

                            <Form.Item
                              className={`input-model ${
                                values?.householdCars?.[index]?.VIN?.length > 0
                                  ? "w-[calc(100%-42rem)]"
                                  : "w-[calc(100%-56rem)]"
                              }`}
                              validateStatus={
                                errors?.householdCars?.[index]?.model && "error"
                              }
                              help={errors?.householdCars?.[index]?.model}
                            >
                              <Input
                                onChange={handleChange}
                                onBlur={handleBlur}
                                name={`householdCars.${index}.model`}
                                value={values?.householdCars?.[index]?.model}
                                // errors={errors?.householdCars?.[index]?.model}
                                placeholder="Model"
                              />
                            </Form.Item>

                            {!(
                              values?.householdCars?.[index]?.VIN?.length > 0
                            ) && (
                              <Form.Item
                                className="input-cost-new w-52"
                                validateStatus={
                                  errors?.householdCars?.[index]?.costNew &&
                                  "error"
                                }
                                help={errors?.householdCars?.[index]?.costNew}
                              >
                                <Input
                                  className="text-left"
                                  onChange={handleChange}
                                  onBlur={handleBlur}
                                  name={`householdCars.${index}.costNew`}
                                  value={
                                    values?.householdCars?.[index]?.costNew
                                  }
                                  // errors={errors?.householdCars?.[index]?.model}
                                  placeholder="Cost New"
                                />
                              </Form.Item>
                            )}

                            <Button
                              className="button-del w-12"
                              type="link"
                              onClick={() => {
                                arrayHelpers.remove(index);
                                dispatch(
                                  toggleOffCar(householdCars?.[index] || {})
                                );
                              }}
                            >
                              <CloseOutlined />
                            </Button>
                          </div>
                        ))}
                      {values.householdCars?.length < 6 && (
                        <Button
                          className="form-button-add"
                          onClick={() =>
                            arrayHelpers.push({
                              year: undefined,
                              make: undefined,
                              model: undefined,
                              VIN: undefined,
                            })
                          }
                        >
                          ADD +
                        </Button>
                      )}
                    </>
                  )}
                />
                <div className="actions">
                  <Spin
                    spinning={false}
                    delay={500}
                    style={{ width: "24.8rem" }}
                  >
                    <Button
                      className="form-submit-button"
                      disabled={false}
                      onClick={handleSubmit}
                    >
                      Continue
                      <Image
                        className="button-icon"
                        preview={false}
                        src={IconArrowRight.src ?? ""}
                        alt=""
                      />
                    </Button>
                  </Spin>
                </div>
              </Form>
            )}
          />
        </Col>
        <Col className="image" xs={24} md={24} lg={7} xl={8} align="center">
          <Image
            preview={false}
            src={getImage(user?.autoimage) || defaultImage}
          />
        </Col>
      </Row>
    </div>
  );
}

Module.propTypes = {
  validationSchema: shape({}).isRequired,
  onStepSubmitted: func.isRequired,
};

export default Module;

const carMakers = [
  "Tesla",
  "Acura",
  "Alfa Romero",
  "Audi",
  "Bentley",
  "BMW",
  "Buick",
  "Cadillac",
  "Chevrolet",
  "Chrysler",
  "Dodge",
  "Ferrari",
  "Fiat",
  "Ford",
  "Genesis",
  "GMC",
  "Honda",
  "Hyundai",
  "Infiniti",
  "Isuzu",
  "Jaguar",
  "Jeep",
  "Kia",
  "Lamborghini",
  "Land Rover",
  "Lexus",
  "Lincoln",
  "Maserati",
  "Mazda",
  "Mercedes",
  "Mini",
  "Mitsbushi",
  "Nissan",
  "Porsche",
  "RAM",
  "Rolls-Royce",
  "Saturn",
  "Subaru",
  "Tesla",
  "Toyota",
  "Volkswagen",
  "VOLVO",
];
