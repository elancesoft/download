import { useSelector } from "react-redux";
import { Image, Button, Row, Col } from "antd";
import { func } from "prop-types";
import IconQuantify from "../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import { useState } from "react";

const options = ["Yes", "No"];
const describes = ["Best Price", "Value", "Best Coverage"];
const describeValue = { "Best Price": 1, Value: 2, "Best Coverage": 3 };

function Module({ onStepSubmitted }) {
  const riskSelectedOption = useSelector(
    (state) => state?.quoteRequest?.riskOption1 ?? ""
  );
  const [value, setValue] = useState(describeValue[riskSelectedOption] || 1);

  const pickOption = (value) => {
    onStepSubmitted({
      riskOption1: value,
    });
  };

  return (
    <Row gutter={[16, 24]} align="center" className="form-risk-score one">
      {/* <Col xs={24} align="right">
        <Button
          className="form-submit-button skip-button"
          onClick={() => pickOption("")}
        >
          Skip
          <Image
            className="button-icon"
            preview={false}
            src={IconArrowRight.src ?? ""}
            alt=""
          />
        </Button>
      </Col> */}
      <Col xs={24} md={14} align="center">
        <Image
          rootClassName="form-quantified-risk-icon"
          preview={false}
          src={IconQuantify.src ?? ""}
          alt=""
        />
        <h4 className="text-[30px] text-center font-semibold leading-tight">
          Which of the following best describes you?
        </h4>
        {/* <h4 className="title">
          Would you pay $125 each year to avoid a 4% chance of losing 15,000?
        </h4> */}
        <div className="text-[14px] text-[#00b4ff] my-[16px]">1 of 5</div>
        <div>
          <input
            type="range"
            min="1"
            max="3"
            step="1"
            className="range"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
        <div className="desc-page-1">
          <div>
            <p className="title">Best Price</p>
            <div className="text">
              Risk <span className="blue-dot"></span>
              <span className="blue-dot"></span>
              <span className="blue-dot"></span>
            </div>
            <div className="text">
              Price <span className="blue-dot"></span>
            </div>
          </div>
          <div>
            <p className="title">Value</p>
            <div className="text">
              Risk <span className="blue-dot"></span>
              <span className="blue-dot"></span>
            </div>
            <div className="text">
              Price <span className="blue-dot"></span>
              <span className="blue-dot"></span>
            </div>
          </div>
          <div>
            <p className="title">Best Coverage</p>
            <div className="text">
              Risk <span className="blue-dot"></span>
            </div>
            <div className="text">
              Price <span className="blue-dot"></span>
              <span className="blue-dot"></span>
              <span className="blue-dot"></span>
            </div>
          </div>
        </div>
        <div className="options">
          <Button
            className={`form-submit-button style-one`}
            onClick={() => pickOption(describes[value - 1])}
          >
            Next
          </Button>
        </div>
        {/* <div className="options">
          {options.map((option) => (
            <Button
              key={option}
              className={`form-submit-button style-one ${
                riskSelectedOption === option ? "selected" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              {option}
            </Button>
          ))}
        </div> */}
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
