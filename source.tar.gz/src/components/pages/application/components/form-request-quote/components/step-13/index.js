import { useSelector } from "react-redux";
import { useFormik } from "formik";
import { Form, Col, Row, Image, Input, Radio, Button } from "antd";
import { func } from "prop-types";
import { object, string, number } from "yup";
import { useState } from "react";
import { getImage } from "../../../../../../../utils/string";

import IconPriceTag from "../../../../../../../../public/images/pages/application/application_form_icon_price_tag.svg";

const defaultImage =
  "/images/pages/application/application_form_image_default_1.svg";
function Module({ onStepSubmitted }) {
  const quoteRequest = useSelector(
    (state) => state?.quoteRequest?.currentPremium
  );
  const user = useSelector((store) => store.user);

  const _formik = useFormik({
    initialValues: {
      price: !isNaN(+quoteRequest?.currentPremium?.price)
        ? quoteRequest?.currentPremium?.price
        : "",
      unit: quoteRequest?.currentPremium?.unit || "month",
    },
    validationSchema: object().shape({
      price: string(),
      unit: string(),
    }),
    onSubmit: (values) => {
      if (values?.price) onStepSubmitted({ currentPremium: values });
    },
  });

  const handleUnitChagned = (e) => {
    _formik.setFieldValue("unit", e.target.value);
  };

  const handleSelectPrice = (type) => {
    if (type === "dont_know") {
      _formik.setFieldValue("price", "I don't know");
      _formik.handleSubmit();
    } else if (type === "price") {
      if (!isNaN(+_formik.values.price)) {
        _formik.handleSubmit();
      }
    }
  };

  return (
    <Form className="form-step-13" onFinish={_formik.handleSubmit}>
      <Row>
        <Col className="text" xs={24} lg={12} align="center">
          <div>
            <h4 className="title">What is you Current premium?</h4>
          </div>

          <Row className="form-group">
            <Image
              rootClassName="icon-price-tag"
              preview={false}
              src={IconPriceTag.src}
              alt=""
            />
            <Form.Item
              className="input-price"
              validateStatus={isNaN(+_formik.values.price) && "error"}
              help={isNaN(+_formik.values.price) && "Price must be number"}
            >
              <Input
                type="text"
                onChange={_formik.handleChange}
                onBlur={_formik.handleBlur}
                name="price"
                value={_formik.values.price}
                errors={_formik.errors.price}
                placeholder="-"
              />
            </Form.Item>
          </Row>

          <Row className="switch-group" align="center">
            <Radio.Group
              value={_formik.values.unit}
              onChange={handleUnitChagned}
            >
              <Radio.Button value="month">Month</Radio.Button>
              <Radio.Button value="year">Year</Radio.Button>
            </Radio.Group>
          </Row>

          <Row gutter={[16, 16]} className="actions">
            <Col xs={24} align="center">
              <Button
                className="form-submit-button"
                onClick={() => handleSelectPrice("dont_know")}
              >
                I don't know
              </Button>
            </Col>

            <Col xs={24} align="center">
              <Button
                className="form-submit-button"
                onClick={() => handleSelectPrice("price")}
              >
                Continue
              </Button>
            </Col>
          </Row>
        </Col>
        <Col className="image" xs={24} lg={12} align="center">
          <Image
            preview={false}
            src={getImage(user?.autoimage) || defaultImage}
          />
        </Col>
      </Row>
    </Form>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
