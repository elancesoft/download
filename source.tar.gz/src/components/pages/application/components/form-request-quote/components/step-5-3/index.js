import { Image, Button, Col, Row } from "antd";
import { func } from "prop-types";
import IconQuantify from "../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import { useSelector } from "react-redux";

// const options = [
//   'Get me the most coverage',
//   'Get me the best combo of low price and great coverage',
//   'Get me the lowest price',
// ];

const options = ["Yes", "No"];

function Module({ onStepSubmitted }) {
  const riskSelectedOption = useSelector(
    (state) => state?.quoteRequest?.riskOption2 ?? ""
  );

  const pickOption = (value) => {
    onStepSubmitted({
      riskOption2: value,
    });
  };

  return (
    <Row gutter={[16, 24]} align="center" className="form-risk-score two">
      {/* <Col xs={24} align="right">
        <Button
          className="form-submit-button skip-button"
          onClick={() => pickOption("")}
        >
          Skip
          <Image
            className="button-icon"
            preview={false}
            src={IconArrowRight.src ?? ""}
            alt=""
          />
        </Button>
      </Col> */}
      <Col xs={24} md={24} lg={14} align="center">
        <Image
          rootClassName="form-quantified-risk-icon"
          preview={false}
          src={IconQuantify.src ?? ""}
          alt=""
        />
        {/* <h4 className="title">
          Which of the following do you most agree with?
        </h4> */}
        <h4 className="text-[30px] text-center font-semibold leading-tight">
          Would you consider a higher deductible to lower your premium?
        </h4>
        <div className="text-[14px] text-[#00b4ff] my-[16px]">2 of 5</div>
        <div className="w-full space-y-4">
          {options.map((option, i) => (
            <div
              className={`max-w-[500px] h-16 leading-[4rem] border border-solid border-black rounded-lg mx-auto transition-colors hover:bg-black hover:text-white cursor-pointer ${
                riskSelectedOption === option ? "bg-black text-white" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              {option}
            </div>
          ))}
        </div>
        {/* <div className="options">
          {
            options.map((option) => (
              <Button className={`form-submit-button style-one ${riskSelectedOption === option ? 'selected' : ''}`} onClick={() => pickOption(option)}>
                {option}
              </Button>
            ))
          }
        </div> */}
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
