import {
  Row,
  Col,
  Checkbox,
  Button,
  Image,
  Switch,
  Input,
  message,
} from "antd";
import { useSelector, useDispatch } from "react-redux";
import { useState, Fragment } from "react";
import { func } from "prop-types";
import { submitFormApply } from "actions";
import { updateQuote } from "redux/slices/quoteRequestSlice";
import { getImage } from "../../../../../../../utils/string";

const defaultImage =
  "/images/pages/application/House&Person_v1_transparent.svg";

const questionOptions = [
  { text: "Short Term Rentals(airBnB,etc)?", field: "termRental" },
  { text: "Property owned by corporation or a trust?", field: "propertyOwn" },
  { text: "Multiple Unit Property?", field: "multipleUnit" },
  {
    text: "Have you filed any property insurance claims?",
    field: "insuranceClaims",
  },
  {
    text: "Have you ever had a policy cancelled or non-renewed in 3 last years?",
    field: "policyRenewed",
  },
  {
    text: "Does your property have an HOA that provides coverage for your building's structure?",
    field: "hoaCoverage",
  },
  { text: "Do you have a swimming pool?", field: "swimmingPool" },
];

const swimmingTypeOptions = [
  { text: "diving board", field: "divingBoard" },
  { text: "slide", field: "slide" },
  { text: "above ground", field: "noneOfThese" },
  { text: "none of these", field: "aboveGround" },
];

function Module({ onStepSubmitted }) {
  const dispatch = useDispatch();
  const quoteRequest = useSelector((store) => store.quoteRequest);
  const { propertyAddress } = useSelector((store) => store.quoteRequest);
  const user = useSelector((state) => state.user);
  const [propertyData, setPropertyData] = useState({
    termRental: quoteRequest.termRental || false,
    propertyOwn: quoteRequest.propertyOwn || false,
    multipleUnit: quoteRequest.multipleUnit || false,
    insuranceClaims: quoteRequest.insuranceClaims || false,
    insuranceClaimDesc: quoteRequest.insuranceClaimDesc || "",
    policyRenewed: quoteRequest.policyRenewed || false,
    swimmingPool: quoteRequest.swimmingPool || false,
    swimmingType: quoteRequest.swimmingType || {
      divingBoard: false,
      slide: false,
      noneOfThese: false,
      aboveGround: false,
    },
    hoaCoverage: quoteRequest.hoaCoverage || false,
  });

  const handleChangeDiscountsData = (field, value) => {
    // if (field.startsWith('swimmingType.')) {
    //   setPropertyData((prev) => ({
    //     ...prev,
    //     swimmingType: {
    //       divingBoard: false,
    //       slide: false,
    //       noneOfThese: false,
    //       aboveGround: false,
    //       [field.substring(14)]: value,
    //     },
    //   }));
    // } else {
    setPropertyData((prev) => ({ ...prev, [field]: value }));
    // }
  };

  const handleSwimmingTypeChanged = (field, value) => {
    setPropertyData((prev) => ({
      ...prev,
      swimmingType: {
        divingBoard: false,
        slide: false,
        noneOfThese: false,
        aboveGround: false,
        [field]: value,
      },
    }));
  };

  const handleSubmit = () => {
    onStepSubmitted({ ...propertyData });
    const formData = new FormData();
    formData.append(
      "data",
      JSON.stringify({
        ...quoteRequest,
        user,
        ...propertyData,
      })
    );

    submitFormApply(formData)
      .then((res) => {
        dispatch(updateQuote({ _id: res.data._id }));
        message.success("Submited!");
      })
      .catch((error) => {
        message.error("Have an error when submit your form!");
      });
  };

  return (
    <section className="step-page-9">
      <Row gutter={[24, 24]}>
        <Col xs={24} md={14}>
          <div className="address-bar">
            <img src="/images/pages/application/locationmarker.svg" />
            <span>{propertyAddress}</span>
          </div>
          <Row gutter={[24, 24]} className="content">
            {questionOptions.map((item, i) => (
              <Fragment key={i}>
                <Col xs={14} md={16} lg={18} className="house_question_text">
                  {item.text}
                </Col>
                <Col xs={10} md={8} lg={6} className="house_question_switch">
                  <span>No</span>
                  <Switch
                    checked={propertyData?.[item.field]}
                    onChange={(value) =>
                      handleChangeDiscountsData(item.field, value)
                    }
                  />
                  <span>Yes</span>
                </Col>
                {item.field === "insuranceClaims" &&
                  propertyData.insuranceClaims && (
                    <Col xs={24}>
                      <Input
                        value={propertyData.insuranceClaimDesc}
                        onChange={(e) =>
                          handleChangeDiscountsData(
                            "insuranceClaimDesc",
                            e.target.value
                          )
                        }
                        placeholder="Insurance Claims Description"
                      />
                    </Col>
                  )}
              </Fragment>
            ))}
          </Row>
          {propertyData.swimmingPool && (
            <Row gutter={[16, 16]} className="swimming-type-content">
              {swimmingTypeOptions.map((item, i) => (
                <Col xs={24} lg={6} key={i}>
                  <Checkbox
                    checked={propertyData?.swimmingType?.[item.field]}
                    onChange={(e) =>
                      handleSwimmingTypeChanged(item.field, e.target.checked)
                    }
                  >
                    {item.text}
                  </Checkbox>
                </Col>
              ))}
            </Row>
          )}
          <Button className="form-submit-button" onClick={handleSubmit}>
            Continue
            <img
              src="/images/pages/application/application_form_icon_arrow_right.svg"
              alt=""
            />
          </Button>
        </Col>
        <Col xs={24} md={10}>
          <Image
            preview={false}
            src={getImage(user?.propertyimage) || defaultImage}
          />
        </Col>
      </Row>
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
