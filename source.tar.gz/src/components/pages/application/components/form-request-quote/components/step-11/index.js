/* eslint-disable react/prop-types */
import { Col, Select, Image, Row } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { func } from "prop-types";

import { updateQuote } from "../../../../../../../redux/slices/quoteRequestSlice";
import { getImage } from "../../../../../../../utils/string";

const { Option } = Select;

const defaultImage =
  "/images/pages/application/application_form_image_default_1.svg";

const optionsCarriers = {
  Allstate: "Allstate",
  Chubb: "Chubb",
  Erie: "Erie",
  Farmers: "Farmers",
  GEICO: "GEICO",
  "Liberty Mutual": "Liberty Mutual",
  MetLife: "MetLife",
  Nationwide: "Nationwide",
  NJM: "NJM",
  "Plymouth Rock": "Plymouth Rock",
  Progressive: "Progressive",
  "State Farm": "State Farm",
  Travelers: "Travelers",
  USA: "USA",
  Other: "Other",
  None: "",
};

function Module({ onStepSubmitted }) {
  const dispatch = useDispatch();
  const insuranceCarrier = useSelector(
    (state) => state?.quoteRequest?.insuranceCarrier ?? undefined
  );
  const user = useSelector((state) => state.user);

  const onCarrierSelected = (value) => {
    dispatch(
      updateQuote({
        insuranceCarrier: value,
      })
    );
    onStepSubmitted({
      insuranceCarrier: value,
    });
  };

  return (
    <div className="form-step-11">
      <Row>
        <Col className="text" xs={24} lg={15} align="center">
          <div>
            <h4 className="title">
              What insurance carrier do you currently use?
            </h4>
            <div className="description">
              There are a lot of good carriers out there. We’ll check your
              existing carrier for Existing bundle discounts and also check
              other carriers to see if they are more competitive for you!
            </div>
            <Select
              placeholder="Current Carrier"
              value={insuranceCarrier}
              // onChange={onCarrierSelected}
              onSelect={onCarrierSelected}
              suffixIcon={null}
            >
              {Object.keys(optionsCarriers).map((key) => (
                <Option key={key} value={optionsCarriers[key]}>
                  {key}
                </Option>
              ))}
            </Select>
          </div>
        </Col>
        <Col className="image" xs={24} lg={9} align="center">
          <Image
            preview={false}
            src={getImage(user?.householdimage) || defaultImage}
          />
        </Col>
      </Row>
    </div>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
