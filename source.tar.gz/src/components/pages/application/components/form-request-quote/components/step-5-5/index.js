import { Image, Button, Col, Row } from "antd";
import { func } from "prop-types";
import IconQuantify from "../../../../../../../../public/images/pages/application/application_form_icon_quantify.svg";
import IconArrowRight from "../../../../../../../../public/images/pages/application/application_form_icon_arrow_right.svg";
import { useSelector } from "react-redux";

// const options = [
//   "I want a high deductible (most savings)",
//   "I’d like the average deductible (middle)",
//   "I want a low deductible (least savings)",
// ];

const options = [
  "$2,000 Immediately;0 claims on your record so your next claim won’t impact your rates dramatically.",
  "$500 per year over 7 years;1 claim on your record so your 2nd claim will have a large price increase.",
];

function Module({ onStepSubmitted }) {
  const riskSelectedOption = useSelector(
    (state) => state?.quoteRequest?.riskOption4 ?? ""
  );
  const pickOption = (value) => onStepSubmitted({ riskOption4: value });

  return (
    <Row gutter={[16, 24]} align="center" className="form-risk-score two">
      {/* <Col xs={24} align="right">
        <Button
          className="form-submit-button skip-button"
          onClick={() => pickOption("")}
        >
          Skip
          <Image
            className="button-icon"
            preview={false}
            src={IconArrowRight.src ?? ""}
            alt=""
          />
        </Button>
      </Col> */}
      <Col xs={24} md={24} lg={18} align="center">
        <Image
          rootClassName="form-quantified-risk-icon"
          preview={false}
          src={IconQuantify.src ?? ""}
          alt=""
        />
        {/* <h4 className="title">
          Would you consider carrying a higher deductible to save money?
        </h4> */}
        <h4 className="text-[30px] text-center font-semibold leading-tight">
          If you file a claim, your insurance rates can increase! Would you
          rather pay $2,000 out of pocket immediately or $500 per year over 7
          years?
        </h4>
        <div className="text-[14px] text-[#00b4ff] my-[16px]">4 of 5</div>
        <div className="flex w-full -mx-2">
          {options.map((option, i) => (
            <div
              className={`flex flex-col border border-solid border-black rounded-lg mx-2 p-4 transition-colors hover:bg-black hover:text-white cursor-pointer ${
                riskSelectedOption === option ? "bg-black text-white" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              <p className="text-[24px] text-blue-500 font-semibold">
                {["A", "B"][i]}.
              </p>
              <p className="max-w-[120px] mt-4 pb-2 mx-auto">
                {option.split(";")[0]}
              </p>
              <hr />
              <p className="w-4/5 mt-3 mx-auto mb-[40px]">{option.split(";")[1]}</p>
            </div>
          ))}
        </div>
        {/* <div className="options">
          {options.map((option) => (
            <Button
              className={`form-submit-button style-one ${
                riskSelectedOption === option ? "selected" : ""
              }`}
              onClick={() => pickOption(option)}
            >
              {option}
            </Button>
          ))}
        </div> */}
      </Col>
    </Row>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;
