import {
  Row,
  Col,
  Upload,
  Button,
  Input,
  Spin,
  message,
  Image,
  Checkbox,
} from "antd";
import {
  FileAddOutlined,
  FileOutlined,
  DeleteOutlined,
} from "@ant-design/icons";
import { useDispatch, useSelector } from "react-redux";
import { useState, useEffect, Fragment } from "react";
import { func, shape } from "prop-types";
import moment from "moment";
import { convertToSortSize } from "../../../../../../../utils";
import {
  getNationwide,
  getTravelerHome,
  getAAAHome,
  getNationwideAuto,
  getTravelerAuto,
  getAAAAuto,
  sendMailUploadFile,
  submitFormApply,
  updateFormApply,
} from "../../../../../../../actions";
import { updateQuote } from "../../../../../../../redux/slices/quoteRequestSlice";
import { updateUser } from "../../../../../../../redux/slices/userSlice";
import { updateApiResult } from "../../../../../../../redux/slices/apiResultSlice";
import { getAddressComponent } from "../../../../../../../utils";
import { getImage } from "../../../../../../../utils/string";
import useRequestBody from "hooks/useRequestBody";

const defaultImage =
  "/images/pages/application/application_form_image_default_1.svg";

function Module({ onStepSubmitted, skipToStep }) {
  const dispatch = useDispatch();
  const quoteRequest = useSelector((state) => state?.quoteRequest);
  const apiResult = useSelector((state) => state?.apiResult ?? {});
  const user = useSelector((state) => state?.user);
  const [files, setFiles] = useState(quoteRequest?.uploadedDocuments ?? []);
  const [note, setNote] = useState(quoteRequest?.note || "");
  const [isOpenConfirmModal, setOpenConfirmModal] = useState(false);
  const {
    nationwideHomeBody,
    travelerHomeBody,
    aaaHomeBody,
    nationwideAutoBody,
    travelerAutoBody,
    aaaAutoBody,
  } = useRequestBody();

  let canSubmit = true;

  const handleSubmit = () => {
    onStepSubmitted({ note });
    const formData = new FormData();

    formData.append("data", JSON.stringify({ ...quoteRequest, user, note }));
    formData.append("page", '14');
    for (let i = 0; i < files.length; i++) {
      formData.append("file_" + i, files[i].originFileObj);
    }

    dispatch(updateQuote({ uploadedDocuments: files, note }));
    dispatch(updateUser({ ...user, note }));

    submitFormApply(formData)
      .then((res) => {
        dispatch(updateQuote({ _id: res.data._id }));
        if (user?.isEnableApi) {
          updatePrice(res.data._id);
        }
        message.success("Submited!");
      })
      .catch((error) => {
        message.error("Have an error when submit your form!");
        skipToStep(18);
      });
  };

  const updatePrice = (_id) => {
    getAddressComponent(quoteRequest.propertyAddress)
      .then((res) => {
        if (user?.nationwide_api?.isOn && !quoteRequest.nationwideHomePrice) {
          getNationwide(nationwideHomeBody()) // home
            .then((res) => {
              console.log("nationwide_home 2", res.data);
              if (!quoteRequest.nationwideHomePrice) {
                let nationwideHomePrice = res.data?.homePrice || 0;
                if (nationwideHomePrice) {
                  dispatch(updateQuote({ nationwideHomePrice }));
                  updateFormApply({ _id, nationwideHomePrice })
                    .then(() => {})
                    .catch(console.log);
                }
              }
            })
            .catch((error) => {
              console.log("nationwide_home 2 error", error);
            });
        }

        if (user?.traveler_api?.isOn && !quoteRequest.travelerHomePrice) {
          getTravelerHome(travelerHomeBody()) // home
            .then((res) => {
              console.log("traveler_home 2", res.data);
              if (!quoteRequest.travelerHomePrice) {
                let travelerHomePrice =
                  +res.data?.homePrice ||
                  +res.data?.result?.IntegratedPartnerHomeQuoteResponse
                    ?.IntegratedPartnerHomeQuoteOutput?.[0]?.Output?.[0]
                    ?.ACORD?.[0]?.InsuranceSvcRs?.[0]?.HomePolicyQuoteInqRs?.[0]
                    ?.PolicySummaryInfo?.[0]?.FullTermAmt?.[0]?.Amt?.[0] ||
                  0;
                let travelerHomeUrl =
                  res.data?.homeUrl ||
                  res.data?.result?.IntegratedPartnerHomeQuoteResponse
                    ?.IntegratedPartnerHomeQuoteOutput?.[0]?.Output?.[0]
                    ?.ACORD?.[0]?.InsuranceSvcRs?.[0]
                    ?.HomePolicyQuoteInqRs?.[0]?.[
                    "com.travelers_NextActionsAvailable"
                  ]?.[0]?.Actions?.[0]?.Action?.[0]?.ActionURL?.[0];
                if (travelerHomePrice) {
                  dispatch(updateQuote({ travelerHomePrice, travelerHomeUrl }));
                  updateFormApply({ _id, travelerHomePrice, travelerHomeUrl })
                    .then(() => {})
                    .catch(console.log);
                }
              }
            })
            .catch((error) => {
              console.log("traveler_home 2 error", error);
            });
        }

        if (user?.aaa_api?.isOn && !quoteRequest.aaaHomePrice) {
          getAAAHome(aaaHomeBody()) // home
            .then((res) => {
              console.log("aaa_home 2", res.data);
              if (!quoteRequest.aaaHomePrice) {
                let aaaHomePrice = +res.data?.homePrice || 0;
                let aaaHomeUrl =
                  res.data?.homeUrl || res.data?.result?.provider?.URLs?.URL;
                if (aaaHomePrice) {
                  dispatch(updateQuote({ aaaHomePrice, aaaHomeUrl }));
                  updateFormApply({ _id, aaaHomePrice, aaaHomeUrl })
                    .then(() => {})
                    .catch(console.log);
                }
              }
            })
            .catch((error) => {
              console.log("aaa_home 2 error", error);
            });
        }
      })
      .catch((error) => {
        console.log(error);
      });

    if (quoteRequest.householdCars?.length > 0) {
      if (user?.nationwide_api?.isOn && !quoteRequest.nationwideAutoPrice) {
        getNationwideAuto(nationwideAutoBody())
          .then((res) => {
            console.log("nationwide_auto 2", res.data);
            if (!quoteRequest.nationwideAutoPrice) {
              let nationwideAutoPrice = res.data?.autoPrice || 0;
              if (nationwideAutoPrice) {
                dispatch(updateQuote({ nationwideAutoPrice }));
                updateFormApply({ _id, nationwideAutoPrice })
                  .then(() => {})
                  .catch(console.log);
              }
            }
          })
          .catch((error) => {
            console.log("nationwide_auto 2 error", error);
          });
      }

      if (user?.traveler_api?.isOn && !quoteRequest.travelerAutoPrice) {
        getTravelerAuto(travelerAutoBody())
          .then((res) => {
            console.log("traveler_auto 2", res.data);
            if (!quoteRequest.travelerAutoPrice) {
              let travelerAutoPrice =
                +res.data?.autoPrice ||
                +res.data?.result.IntegratedPartnerAutoQuoteResponse
                  ?.IntegratedPartnerAutoQuoteOutput?.[0]?.Output?.[0]
                  ?.ACORD?.[0]?.InsuranceSvcRs?.[0]
                  ?.PersAutoPolicyQuoteInqRs?.[0]?.PolicySummaryInfo?.[0]
                  ?.FullTermAmt?.[0]?.Amt?.[0] ||
                0;
              if (travelerAutoPrice) {
                dispatch(updateQuote({ travelerAutoPrice }));
                updateFormApply({ _id, travelerAutoPrice })
                  .then(() => {})
                  .catch(console.log);
              }
            }
          })
          .catch((error) => {
            console.log("traveler_auto 2 error", error);
          });
      }

      if (user?.aaa_api?.isOn && !quoteRequest.aaaAutoPrice) {
        getAAAAuto(aaaAutoBody())
          .then((res) => {
            console.log("traveler_auto 2", res.data);
            if (!quoteRequest.aaaAutoPrice) {
              let aaaAutoPrice = +res.data?.autoPrice || 0;
              if (aaaAutoPrice) {
                dispatch(updateQuote({ aaaAutoPrice }));
                updateFormApply({ _id, aaaAutoPrice })
                  .then(() => {})
                  .catch(console.log);
              }
            }
          })
          .catch((error) => {
            console.log("traveler_auto 2 error", error);
          });
      }
    }
  };

  const handleChange = ({ fileList }) => {
    if (fileList.length > 4) {
      message.error("Do not upload more than 4 photos");
      return;
    }
    setFiles(fileList);
  };

  const fileItemRender = (originNode, file, fileList, actions) => (
    <div className="file-preview">
      <div className="icon">
        <FileOutlined />
        <span className="ext">{file.name.replace(/(.+\.)/g, "")}</span>
      </div>
      <div className="content">
        <p className="name">{file.name}</p>
        <div className="process" />
        <p className="size">{convertToSortSize(file.size)}</p>
        <span />
      </div>
      <div className="action">
        <DeleteOutlined onClick={actions.remove} />
      </div>
    </div>
  );

  return (
    <section className="step-page-14">
      <Row gutter={[24, 24]}>
        <Col xs={24} md={14} lg={10}>
          <h2 className="title">File Upload</h2>
          <p className="text-small">
            Please upload any documents you have that could help us. Current Dec
            Pages, Drivers License Numbers, Home info, etc.{" "}
          </p>
          <Upload.Dragger
            className="upload-file"
            name="file"
            // action="https://apply.insure/fileupload"
            fileList={files}
            multiple
            onChange={handleChange}
            beforeUpload={() => false}
            iconRender={() => "abc"}
            itemRender={fileItemRender}
          >
            <div className="upload-file-icon">
              <FileAddOutlined />
            </div>
            <p className="text-small">
              Drag and drop or <span className="mark">browse</span> your files.
            </p>
          </Upload.Dragger>
          <p className="text-small margin-top">
            Let us know any comments that will help us insure you better.{" "}
          </p>
          <Input.TextArea
            rows={4}
            maxLength={200}
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <Spin spinning={!canSubmit} delay={500} style={{ width: "24.8rem" }}>
            <Button
              disabled={!canSubmit}
              className="form-submit-button"
              onClick={() => setOpenConfirmModal(true)}
            >
              Continue
              <img
                src="/images/pages/application/application_form_icon_arrow_right.svg"
                alt=""
              />
            </Button>
          </Spin>
        </Col>
        <Col xs={0} lg={4} />
        <Col xs={24} md={10} lg={10}>
          <Image
            preview={false}
            src={getImage(user?.introimage) || defaultImage}
          />
        </Col>
      </Row>
      <ConfirmPopup
        open={isOpenConfirmModal}
        onClose={() => setOpenConfirmModal(false)}
        onSubmit={handleSubmit}
      />
    </section>
  );
}

Module.propTypes = {
  onStepSubmitted: func.isRequired,
};

export default Module;

const ConfirmPopup = ({ open, onClose, onSubmit }) => {
  const [isAgree, setAgree] = useState(false);

  return open ? (
    <>
      <div
        className="fixed inset-0 bg-black bg-opacity-70 z-[200]"
        onClick={onClose}
      ></div>
      <div className="fixed w-[90%] xl:w-[1000px] top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[200] bg-[#f5f5f5] text-[#4E4E4E] p-[32px] rounded-[24px]">
        <h2 className="text-[35px] text-center">Submit</h2>
        <p className="text-[14px] text-center">
          Do you acknowledge your answers are accurate to your knowledge? Do you
          agree to let insurance carriers run a required soft credit hit
          (doesn’t impact credit score) so they make insurance offers to you?
        </p>
        <div className="flex justify-between items-center md:w-[85%] mx-auto mt-[16px] mb-[80px]">
          <img src="/images/pages/application/confirm-icon.svg" />
          <div>
            <Checkbox
              defaultChecked={isAgree}
              onChange={(e) => setAgree(e.target.checked)}
            >
              I Agree
            </Checkbox>
            <button
              className="flex justify-around items-center w-[285px] h-16 bg-white disabled:bg-[#f5f5f5] border border-black rounded-[4px] mt-[16px] transition-colors hover:bg-black hover:text-white hover:disabled:text-black cursor-pointer disabled:cursor-not-allowed"
              onClick={onSubmit}
              disabled={!isAgree}
            >
              Submit
              <img
                src="/images/pages/application/application_form_icon_arrow_right.svg"
                alt=""
              />
            </button>
          </div>
          <div></div>
        </div>
      </div>
    </>
  ) : null;
};
