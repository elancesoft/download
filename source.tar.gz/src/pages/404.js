import Link from 'next/link';
import { Row, Col } from 'antd';
import LayoutLanding from '../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-404">
      <div className="container">
        <Row>
          <Col xs={24} align="center">
            <h1 className="title">
              Well, it seems that this page is missing.
            </h1>

            <Link href="/" className="button primary outlined">
              Go back to home page
            </Link>
          </Col>
        </Row>
      </div>
    </LayoutLanding>
  );
}

export default Page;
