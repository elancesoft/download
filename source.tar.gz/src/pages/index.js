import LayoutLanding from "../components/layouts/landing";
import ModuleHero from "../components/pages/home/components/hero";
import ModuleSignupBanner from "../components/pages/home/components/signup-banner";
import ModuleServices from "../components/pages/home/components/services";
import ModuleFeatures from "../components/pages/home/components/features";
import ModuleGetYourApp from "../components/pages/home/components/get-your-apps";

function Page() {
  return (
    <LayoutLanding pageClassname="page-home">
      <ModuleSignupBanner />
      <ModuleServices />
      <ModuleFeatures />
      <ModuleGetYourApp />
    </LayoutLanding>
  );
}

export default Page;
