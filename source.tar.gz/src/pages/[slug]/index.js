import { useRouter } from 'next/router';
import { useEffect } from 'react';

// eslint-disable-next-line react/prop-types
function Page() {
  const router = useRouter();
  const { slug } = router.query;

  useEffect(() => {
    if (slug) {
      router.push(`/f/${slug}`);
    }
  }, [slug]);

  return <>Redirecting...</>;
}

export default Page;
