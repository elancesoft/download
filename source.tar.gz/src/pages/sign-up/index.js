import LayoutLanding from '../../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-sign-up">
      <h1>Page Sign Up</h1>
    </LayoutLanding>
  );
}

export default Page;
