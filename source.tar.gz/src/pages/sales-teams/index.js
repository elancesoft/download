import LayoutLanding from '../../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-sale-teams">
      <h1>Page Sales Teams</h1>
    </LayoutLanding>
  );
}

export default Page;
