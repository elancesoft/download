import LayoutLanding from '../../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-individuals">
      <h1>Page Individuals</h1>
    </LayoutLanding>
  );
}

export default Page;
