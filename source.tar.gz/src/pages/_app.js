import "../styles/main.scss";
import App from "next/app";
import Router from "next/router";
import getConfig from "next/config";
import NProgress from "nprogress";
import { oneOfType, node, func, shape } from "prop-types";
import { DefaultSeo } from "next-seo";

import store from "../redux/store";

const {
  publicRuntimeConfig: { BASE_IMAGE_URL },
} = getConfig();

const defaultImageSrc = "/images/default-preview-image.png";
const defaultText =
  "Quickly apply online for insurance quotes from multiple top rates carriers!";

Router.events.on("routeChangeStart", () => NProgress.start());
Router.events.on("routeChangeComplete", () => NProgress.done());
Router.events.on("routeChangeError", () => NProgress.done());

function Application({ Component, pageProps }) {
  return (
    <>
      <DefaultSeo
        title={`Apply Insure`}
        description={defaultText}
        openGraph={{
          title: defaultText,
          description: defaultText,
          images: [
            {
              url: defaultImageSrc,
            },
          ],
        }}
      />
      <Component {...pageProps} />
    </>
  );
}

Application.getInitialProps = async (appContext) => {
  const appProps = await App.getInitialProps(appContext);
  return { ...appProps };
};

Application.propTypes = {
  Component: oneOfType([node, func]).isRequired,
  pageProps: shape({}),
};

Application.defaultProps = {
  pageProps: {},
};

export default store.withRedux(Application);
