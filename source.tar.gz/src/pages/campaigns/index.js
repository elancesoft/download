import LayoutLanding from '../../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-campaigns">
      <h1>Page Campaign</h1>
    </LayoutLanding>
  );
}

export default Page;
