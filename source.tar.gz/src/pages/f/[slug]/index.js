import LayoutApplication from "../../../components/layouts/application";
import FormRequestQuote from "../../../components/pages/application/components/form-request-quote";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { updateUser } from "../../../redux/slices/userSlice";
import { getUserByLink } from "../../../actions";
import Router from "next/router";
import getConfig from "next/config";
import { Wrapper } from "@googlemaps/react-wrapper";
import { NextSeo } from "next-seo";

const {
  publicRuntimeConfig: { GOOGLE_MAPS_API_KEY, BASE_IMAGE_URL },
} = getConfig();

const defaultImageSrc = "/images/default-preview-image.png";
const defaultText =
  "Quickly apply online for insurance quotes from multiple top rates carriers!";

const backToHomeProps = {
  redirect: {
    permanent: false,
    destination: "/",
  },
};

export async function getServerSideProps({ params }) {
  try {
    const userResponse = await getUserByLink(params.slug || "");
    return { props: { user: userResponse.data } };
  } catch (error) {
    console.log(error);
    return { props: { user: null } };
  }
}

// eslint-disable-next-line react/prop-types
function Page({ user }) {
  const dispatch = useDispatch();

  useEffect(() => {
    if (!user) {
      Router.push("/");
    } else {
      dispatch(updateUser(user));
    }
  }, []);

  return (
    <>
      <NextSeo
        title={`New Quote`}
        openGraph={{
          title: user?.previewtext || defaultText,
          description: defaultText,
          images: [
            {
              url: user?.previewimage
                ? `${BASE_IMAGE_URL}/${user?.previewimage}`
                : defaultImageSrc,
            },
          ],
        }}
      />
      <Wrapper apiKey={GOOGLE_MAPS_API_KEY}>
        <LayoutApplication pageClassname="page-application">
          <FormRequestQuote />
        </LayoutApplication>
      </Wrapper>
    </>
  );
}

export default Page;
