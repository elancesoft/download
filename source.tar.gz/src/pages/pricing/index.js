import LayoutLanding from '../../components/layouts/landing';

function Page() {
  return (
    <LayoutLanding pageClassname="page-pricing">
      <h1>Page Pricing</h1>
    </LayoutLanding>
  );
}

export default Page;
