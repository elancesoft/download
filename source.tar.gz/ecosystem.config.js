module.exports = {
  apps: [
    {
      name: "applyinsure_frontend",
      script: "yarn start -p 3000",
      autorestart: true,
      log_date_format: "YY-MM-DD HH:mm:ss ",
    },
  ],
};
