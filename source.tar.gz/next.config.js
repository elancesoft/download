/** @type {import('next').NextConfig} */
require("dotenv").config();

const nextConfig = {
  reactStrictMode: true,
  publicRuntimeConfig: {
    // API_URL: "https://api.apply.insure",
    API_URL: "http://apply-api.elancefoxvn.com",
    // API_URL: 'http://localhost:3001',
    API_TIMEOUT: 30000,

    GOOGLE_MAPS_API_KEY: "AIzaSyAqJxkc1a0TqV8ED9ThtsvwJcQoRTlIzhY",

    // BASE_IMAGE_URL: 'https://api.apply.insure/upload/images',
    BASE_IMAGE_URL: "http://apply-api.elancefoxvn.com/upload/images",
  },
  eslint: {
    // Warning: This allows production builds to successfully complete even if
    // your project has ESLint errors.
    ignoreDuringBuilds: true,
  },
};

module.exports = nextConfig;
