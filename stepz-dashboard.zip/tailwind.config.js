module.exports = {
  content: ['./src/{common,pages,components,modules}/**/*.{html,js,jsx,ts,tsx}'],
  mode: 'jit',
  theme: {
    screens: {
      xs: '375px',
      sm: '600px',
      md: '900px',
      lg: '1200px',
      xl: '1500px',
      '2xl': '1906px',
    },
    container: {
      center: true,
      padding: {
        DEFAULT: '0.5rem',
        sm: '1rem',
        lg: '1rem',
        xl: '2rem',
        '2xl': '2em',
      },
    },
    extend: {
    },
  },
  plugins: [],
  corePlugins: {
    preflight: false,
  },
}
