module.exports = {
  apps: [
    {
      name: "stepz_dashboard",
      script: "yarn start -p 4006",
      autorestart: true,
      log_date_format: "YY-MM-DD HH:mm:ss ",
    },
  ],
};
